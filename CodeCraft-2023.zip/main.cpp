#include <iostream>
#include <sstream>
#include <vector>
#include <cstring>
#include <math.h>

using namespace std;
/**
 * 改进方向:更低的碰撞几率,更快的行路算法,更快收益的调度算法
 */
double hyperParameterAngle = 0.35;//运动中运行方向偏差的最大角度
double hyperParameterDistance = 16;//避免碰撞的距离
int hyperParameterSpeed = 6;//运动的速度
double hyperParameterAvoidSpeed = 5.5;//避免碰撞运动的速度
double hyperParameterRobotAngle = 3.14;//转弯的幅度
double hyperParameterAngleCollision = 0.75;//避免碰撞的最大方向偏差角度
double hyperParameterTimeBuy = 1.0;//买东西的时间限制
double hyperParameterTurnSpeed = 0.0;//转向运动的速度
double pi = 3.141592653;
double hyperParameterPriorityMap1 = 3.0;//放大7号工作台对物品456二缺一和一缺二的优先级
int remainingProductionTime = 500;//在什么时候就可以判断7号工作台已经快生产完成了
/**
worktable_type            工作台类型   整数        范围[1, 9]
coordinate_x coordinate_y 坐标        2个浮点 x,y 范围[0,50]即地图大小
remainingProductionTime   剩余生产时间  整数        -1：表示没有生产
（未使用）                                          0：表示生产因输出格满而阻塞。
                                                >=0：表示剩余生产帧数。
rawMaterialCellState     原材料格状态   整数       二进制位表描述，例如 48(110000)表示拥有物品 4 和 5。
productCellStatus        产品格状态    整数        0：表示无。
                                                1：表示有
worktableArrayIndex      工作台数组下标 整数       记录该工作台所在数组的下标
raw_material_cell_robot  分配时材料格的 int[8]    0代表产品材料格,int[0]范围[-1,3].int[0]=-1代表没机器人想买工作台产品,int[0]=robotId代表robotId号机器人想买工作台产品
                         状态                   [1,7]代表原材料格,int[i]范围[-1,3].int[i]=-1代表没有机器人想使用该工作台的i号原材料格,
                                               int[i]=robotId,代表robotId号机器人想使用该工作台的i号原材料格
raw_material_cell        原材料格状态   char[8]  char[i]=0代表可以放第i号物品
                                               char[i]=1代表不可以放第i号物品
*/
typedef struct worktable {
    int worktable_type;
    double coordinate_x;
    double coordinate_y;
    int remainingProductionTime;
    int rawMaterialCellState;
    int productCellStatus;
    int worktableArrayIndex;
    int raw_material_cell_robot[8];//存储产品格原材料格的状态-1可以选,状态值为i的只能被机器人i可以选,数组[0]下标为-1代表产品格没人买,i代表有机器人i买
    char raw_material_cell[8];//存储原材料格的状态0可以放,1不可以放
} worktable;
/**
worktable_id                所处工作台ID 整数       -1：表示当前没有处于任何工作台附近
(未使用)                                          [0,工作台总数-1] ：表示某工作台的下标，从 0 开始，按输入顺序定。当前机器人的所有购买、出售行为均针对该工作台进行。
product_type                携带物品类型 整数      范围[0,7]。 0 表示未携带物品。  1-7 表示对应物品。
time_value_coefficient      时间价值系数 浮点      携带物品时为[0.8, 1]的浮点数，不携带物品时为 0
(未使用)
collision_value_coefficient 碰撞价值系数 浮点      携带物品时为[0.8, 1]的浮点数，不携带物品时为 0。
(未使用)
angular_velocity            角速度     浮点       单位：弧度/秒。 正数：表示逆时针。 负数：表示顺时针。
(未使用)
linear_velocity_x           线速度     2个浮点x,y 由二维向量描述线速度，单位：米/秒
linear_velocity_y
(未使用)
orientation                 朝向       浮点      弧度，范围[-π,π]。方向示例： 0：表示右方向。 π/2：表示上方向。 -π/2：表示下方向。
coordinate_x coordinate_y   坐标       2个浮点x,y 机器人坐标
destinationDistance_x       距离       2个浮点x,y 与另一物体在x轴方向与在y轴方向的距离,该变量作用为减少代码长度
destinationDistance_y
robotId                     机器人id   整数       机器人在数组robot_array中的下标
worktableSelectionFlag      flag标记   整数       记录机器人要前往的工作台
*/
typedef struct robot {
    int worktable_id;
    int product_type;
    double time_value_coefficient;
    double collision_value_coefficient;
    double angular_velocity;
    double linear_velocity_x;
    double linear_velocity_y;
    double orientation;
    double coordinate_x;
    double coordinate_y;
    double destinationDistance_x;//与目的地坐标的距离
    double destinationDistance_y;
    int robotId;
    int worktableSelectionFlag = -1;//-1没有选择前往的工作台
} robot;

/**
 *接受地图数据,但我认为没什么用,所以没有接收地图数据
 * @return
 */
bool readUntilOK() {
    char line[1024];
    while (fgets(line, sizeof line, stdin)) {
        if (line[0] == 'O' && line[1] == 'K') {
            return true;
        }
        //do something

    }
    return false;
}

/**
 *接收每一帧的输入数据,接收工作台信息时,使用switch将rawMaterialCellState原材料格状态转化为更容易处理的char数组形式
 * @param frame_id          当前帧数id
 * @param money             当前金额
 * @param k                 工作台个数
 * @param worktable_array   存储k个工作台信息的数组
 * @param robot_array       存储所有机器人信息的数组
 * @param worktable_array7  在第一帧时,存储工作台类型=7的工作台的数组
 * @return 通过&,返回数组worktable_array,robot_array,worktable_array7
 */
bool
input_every_frame(int frame_id, int &money, int k, vector<worktable> &worktable_array, vector<robot> &robot_array,
                  vector<worktable> &worktable_array7) {
    worktable worktable_temp;
    for (int index_r = 0; index_r < 8; index_r++) {
        worktable_temp.raw_material_cell_robot[index_r] = -1;
    }

    robot robot_temp;
    char line[1024];
    int i = 0;
    while (fgets(line, sizeof line, stdin)) {


        if (line[0] == 'O' && line[1] == 'K') {
            return true;
        }
        //do something
        if (i == 0) {
            std::stringstream ss(line);//不知道能不能导入
            ss >> money;
            i++;
            ss.str("");
            ss.clear();
            continue;
        }
        if (i == 1) {
            std::stringstream ss(line);//不知道能不能导入
            ss >> k;
            i++;
            ss.str("");
            ss.clear();
            continue;
        }
        if (i > 1 && i <= 1 + k) {
            std::stringstream ss(line);//不知道能不能导入
            if (frame_id == 1) {//第一帧数组为空,需要插入
                ss >> worktable_temp.worktable_type >> worktable_temp.coordinate_x >> worktable_temp.coordinate_y
                   >> worktable_temp.remainingProductionTime >> worktable_temp.rawMaterialCellState
                   >> worktable_temp.productCellStatus;
                worktable_array.push_back(worktable_temp);
                worktable_temp.worktableArrayIndex = i - 2;
                if (worktable_temp.worktable_type == 7) {//在第一帧记录worktable_array7
                    worktable_array7.push_back(worktable_temp);
                }
            } else {//其他帧数组不为空,直接修改
                ss >> worktable_array[i - 2].worktable_type >> worktable_array[i - 2].coordinate_x
                   >> worktable_array[i - 2].coordinate_y
                   >> worktable_array[i - 2].remainingProductionTime >> worktable_array[i - 2].rawMaterialCellState
                   >> worktable_array[i - 2].productCellStatus;
            }
            worktable_array[i - 2].worktableArrayIndex = i - 2;
            //原材料格的记录有些问题,尝试用最笨的方法修改
            switch (worktable_array[i - 2].worktable_type) {//设置原材料格的状态
                case 1://没有原材料格
                    strcpy(worktable_array[i - 2].raw_material_cell, "11111111");
                    break;
                case 2://没有原材料格
                    strcpy(worktable_array[i - 2].raw_material_cell, "11111111");
                    break;
                case 3://没有原材料格
                    strcpy(worktable_array[i - 2].raw_material_cell, "11111111");
                    break;
                case 4://有1和2,对应rawMaterialCellState四种状态,0,2(1),4(2),6(1和2)
                    switch (worktable_array[i - 2].rawMaterialCellState) {
                        case 0:
                            strcpy(worktable_array[i - 2].raw_material_cell, "10011111");
                            break;
                        case 2:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11011111");
                            break;
                        case 4:
                            strcpy(worktable_array[i - 2].raw_material_cell, "10111111");
                            break;
                        case 6:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11111111");
                            break;
                    }
                    break;
                case 5://有1和3,对应rawMaterialCellState四种状态,0,2(1),8(3),10(1和3)
                    switch (worktable_array[i - 2].rawMaterialCellState) {
                        case 0:
                            strcpy(worktable_array[i - 2].raw_material_cell, "10101111");
                            break;
                        case 2:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11101111");
                            break;
                        case 8:
                            strcpy(worktable_array[i - 2].raw_material_cell, "10111111");
                            break;
                        case 10:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11111111");
                            break;
                    }
                    break;
                case 6://有2和3,对应rawMaterialCellState四种状态,0,4(2),8(3),12(2和3)
                    switch (worktable_array[i - 2].rawMaterialCellState) {
                        case 0:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11001111");
                            break;
                        case 4:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11101111");
                            break;
                        case 8:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11011111");
                            break;
                        case 12:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11111111");
                            break;
                    }
                    break;
                case 7://有4,5和6,对应rawMaterialCellState八种状态,0,16(4),32(5),64(6),48(4和5),80(4和6),96(5和6),112(4,5,6)
                    strcpy(worktable_array[i - 2].raw_material_cell, "11110001");
                    switch (worktable_array[i - 2].rawMaterialCellState) {
                        case 0:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11110001");
                            break;
                        case 16:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11111001");
                            break;
                        case 32:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11110101");
                            break;
                        case 48:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11111101");
                            break;
                        case 64:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11110011");
                            break;
                        case 80:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11111011");
                            break;
                        case 96:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11110111");
                            break;
                        case 112:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11111111");
                            break;
                    }
                    break;
                case 8://有7,对应rawMaterialCellState两种状态,0,128(7)
                    switch (worktable_array[i - 2].rawMaterialCellState) {
                        case 0:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11111110");
                            break;
                        case 128:
                            strcpy(worktable_array[i - 2].raw_material_cell, "11111111");
                            break;
                    }
                    break;
                case 9:
                    strcpy(worktable_array[i - 2].raw_material_cell, "10000000");
            }
            i++;
            ss.str("");
            ss.clear();
            continue;
        }
        if (i > 1 + k && i <= 5 + k) {
            std::stringstream ss(line);//不知道能不能导入
            ss >> robot_array[i - 2 - k].worktable_id >> robot_array[i - 2 - k].product_type
               >> robot_array[i - 2 - k].time_value_coefficient
               >> robot_array[i - 2 - k].collision_value_coefficient >> robot_array[i - 2 - k].angular_velocity
               >> robot_array[i - 2 - k].linear_velocity_x
               >> robot_array[i - 2 - k].linear_velocity_y >> robot_array[i - 2 - k].orientation
               >> robot_array[i - 2 - k].coordinate_x
               >> robot_array[i - 2 - k].coordinate_y;
            robot_array[i - 2 - k].robotId = i - 2 - k;
            i++;
            ss.str("");
            ss.clear();
            continue;
        }
    }
    return false;
}

/**
 *计算机器人robot1与工作台worktable1的距离的平方,之所以算平方是为了降低函数的时间复杂度(好像系统不差这点时间),
 * @param robot1 机器人
 * @param worktable1 工作台
 * @return 二者距离的平方
 */
double distanceSquaredBetweenPoint(robot &robot1, worktable &worktable1) {//计算二点距离的平方
    robot1.destinationDistance_x = worktable1.coordinate_x - robot1.coordinate_x;//计算目的地距离
    robot1.destinationDistance_y = worktable1.coordinate_y - robot1.coordinate_y;
    //distanceLength距离
    double distanceLength = robot1.destinationDistance_x * robot1.destinationDistance_x +
                            robot1.destinationDistance_y * robot1.destinationDistance_y;
    return distanceLength;
}

/**
 * 求机器人robot1离哪个机器人最近,碰撞算法中用到该函数,判断是否有机器人可能因为离得太紧而相撞
 * @param robot1 机器人
 * @param robot_array 机器人数组
 * @param minRobotIndex 记录距离robot1最近的机器人的id
 * @return 返回最小距离minDistance,通过& 返回距离robot1最近的机器人的id(下标):minRobotIndex
 */
double distanceSquaredBetweenRobot(robot &robot1, vector<robot> &robot_array, int &minRobotIndex) {//计算二点距离的平方
    int i;
    double distanceLength, minDistance = 999999.9;
    for (i = 0; i < robot_array.size(); i++) {
        if (robot1.robotId != robot_array[i].robotId) {
            robot1.destinationDistance_x = robot_array[i].coordinate_x - robot1.coordinate_x;//计算目的地距离
            robot1.destinationDistance_y = robot_array[i].coordinate_y - robot1.coordinate_y;
            distanceLength = robot1.destinationDistance_x * robot1.destinationDistance_x +
                             robot1.destinationDistance_y * robot1.destinationDistance_y;
            if (minDistance > distanceLength) {
                minDistance = distanceLength;
                minRobotIndex = robot_array[i].robotId;
            }
        }
    }
    //返回最小距离
    return minDistance;
}

/**
 * 计算两个机器人前进方向的夹角,碰撞算法中用到该函数,如果两个机器人离得太紧,就计算二者前进方向的夹角,如果双方是互相朝着对方的方向行驶,则会发生碰撞
 * @param orientation1 机器人1的朝向
 * @param orientation2 机器人2的朝向
 * @return π-二者朝向的夹角
 */
double angleRobotBetweenOrientation(double orientation1, double orientation2) {
    double angle;
    if (orientation1 >= 0)
        angle = fabs(orientation1 - 3.1416 - orientation2);
    else
        angle = fabs(orientation1 + 3.1416 - orientation2);
    if (angle > 3.1416) {
        return 3.1416 * 2 - angle;
    } else
        return angle;
}

int coordinateTransform(robot robot1, robot robot2, int frameID) {//0不撞,1顺,2逆
    double robot2x, robot2y, orientation2;
    int flag = 0;
    robot2x = (robot2.coordinate_x - robot1.coordinate_x) * cos(-1 * robot1.orientation) -
              (robot2.coordinate_y - robot1.coordinate_y) * sin(-1 * robot1.orientation);
    robot2y = (robot2.coordinate_x - robot1.coordinate_x) * sin(-1 * robot1.orientation) +
              (robot2.coordinate_y - robot1.coordinate_y) * cos(-1 * robot1.orientation);
    orientation2 = robot2.orientation - robot1.orientation;
    if (orientation2 > pi) {
        orientation2 = orientation2 - 2 * pi;
    }
    if (orientation2 < -1 * pi) {
        orientation2 = orientation2 + 2 * pi;
    }

    if (robot2x > -1.1 && robot2x < 4.0 && robot2y > 0 && robot2y < 3) {//四象限的处理比较麻烦
        if (robot2y >= 1.5 && orientation2 <= -1.0 * pi / 3.0 && orientation2 >= -1.0 * pi) {//一象限外半部分,角度在第三象限
            flag = 1;//机2顺时针
        }
        if (robot2y >= 1.5 && orientation2 >= -1.0 * pi / 3.0 && orientation2 < 0) {//一象限外半部分,角度在第四象限
            flag = 2;//机2逆时针
        }
        if (robot2x > 1.1 && robot2y < 1.5) {
            if (orientation2 <= -1.0 * pi / 3.0 && orientation2 >= -1.0 * pi ||
                orientation2 >= 5.0 / 6.0 * pi && orientation2 <= pi)//一象限内半部分,角度在第三象限
                flag = 8;
            else//一象限内半部分,角度在第四象限(因为一二象限不会发生碰撞)
                flag = 5;
        }
        if (robot2x <= 1.1 && robot2y < 1.5) {//一象限内半部分,在靠近y轴的正半轴
            flag = 9;
        }

    }
    if (robot2x > -1.1 && robot2x < 4.0 && robot2y < 0 && robot2y > -3) {//一象限的处理比较麻烦
        if (robot2y <= -1.5 && orientation2 <= pi / 3.0 && orientation2 > 0) {//四象限外半部分,角度在第一象限
            flag = 3;//机2顺时针
        }
        if (robot2y <= -1.5 && orientation2 > pi / 3.0 && orientation2 < pi) {//四象限外半部分,角度在第二象限
            flag = 4;//机2逆时针
        }
        if (robot2x > 1.1 && robot2y > -1.5) {
            if (orientation2 > pi / 3.0 && orientation2 < pi ||
                orientation2 < -5.0 / 6.0 * pi && orientation2 >= -1 * pi)//四象限内半部分,角度在第二象限
                flag = 7;
            else
                flag = 6;//四象限内半部分,角度在第一象限
        }
        if (robot2x <= 1.1 && robot2y > -1.5) {//四象限内半部分,在靠近y轴的负半轴
            flag = 10;
        }
    }

    int i = 0;
    if (flag != 0) {
        for (i = 0; i < 100; i++) {
            // 计算小球1和小球2的当前位置
            double cur_x1 = robot1.coordinate_x + (robot1.linear_velocity_x / 50.0) * i;
            double cur_y1 = robot1.coordinate_y + (robot1.linear_velocity_y / 50.0) * i;
            double cur_x2 = robot2.coordinate_x + (robot2.linear_velocity_x / 50.0) * i;
            double cur_y2 = robot2.coordinate_y + (robot2.linear_velocity_y / 50.0) * i;

            // 计算小球1和小球2的距离
            double distance = pow(cur_x2 - cur_x1, 2) + pow(cur_y2 - cur_y1, 2);

            // 如果小球1和小球2的距离小于等于它们的直径之和，则发生了碰撞
            if (distance <= 1.2) {
                break;
            }
        }
        if (i == 100) {
            flag = 0;
        }
    }

//    //test
//    if (flag != 0)
//        fprintf(stderr, "frameID %d robot1ID %d robot2ID %d robot2x %f robot2y %f orientation2 %f flag %d\n", frameID,
//                robot1.robotId, robot2.robotId,
//                robot2x, robot2y, orientation2, flag);
    return flag;
}

/**  改进方向:更低的碰撞几率,更快的行路算法
 * 机器人行路算法,三个部分:1进行标记,2碰撞检测,3行路
 * 1,机器人先对要前往的工作台进行标记,如果机器人买材料,则对该工作台的产品格进行标记,标记后其他机器人不可以选择该工作台的产品格.如果机器人卖材料a,
 * 则对工作台的原材料格a进行标记,标记后其他机器人不可以选择该工作台的原材料格a
 * 2,进行碰撞检测,如果双方发生了碰撞,将二者分开,分开的方式是双方都顺时针转或逆时针转,然后向着朝向前进.
 * 3.1计算前往工作台的距离,以及工作台与机器人位置构成的向量的角度与机器人朝向的夹角.
 * 3.2如果夹角大于设置的阈值hyperParameterAngle并且离得较远(大于hyperParameterDistance),就边走边调整方向.如果夹角大于设置的阈值并且离得
 * 较近(<=hyperParameterDistance),就减速并调整方向,减速最小可以减到0m/s,调整方向的思路是如果机器人顺时针转动到合适朝向的角度小,就顺时针转,反之逆时针转
 * 3.3如果夹角小于设置的阈值hyperParameterAngle,判断前进过程中是否会发生碰撞,如果不会,就全速冲刺,如果会,就让可能会发生碰撞的双方转向,转向的方式为双方都顺时针转或逆时针转,然后沿着朝向前进.
 * 判断是否碰撞的思路是检查机器人robot1离哪个机器人最近,离机器人robot1的最近的机器人行走方向是不是与他相对而行(robot1-> <-robot2),
 * 如果是,说明会发生碰撞,反之不会如(robot1-> robot2/^/).判断相对而行的标准是(π-二者朝向的夹角<hyperParameterAngleCollision)
 * 3.4如果机器人与工作台的距离小于0.4,说明到达工作台,进行买卖,交易后清除对该工作台的标记
 * @param robot1 机器人
 * @param worktable1 机器人前往的工作台
 * @param robot_array 机器人数组,碰撞检测中用到
 * @param worktable_array 工作台数组,因为在机器人行走的过程中可能会发现更优选择,发现更优选择后机器人会改变目的地,所以机器人之前要前往的目的地的标记要被清除.
 *                        如果不清除标记,会导致其他机器人一直不能选择该工作台
 * @param frameID 调试用
 * @return 无
 */
bool robot_to_destination(robot &robot1, worktable &worktable1, vector<robot> &robot_array,
                          vector<worktable> &worktable_array, int &frameID, vector<worktable> &worktable_array7) {
    if (worktable_array7.size() == 2) {
        hyperParameterAngle = 0.30;//运动中运行方向偏差的最大角度
        hyperParameterDistance = 9;//避免碰撞的距离
        hyperParameterAvoidSpeed = 6.0;
        hyperParameterTurnSpeed = 1.0;
    } else if (worktable_array7.size() == 1) {
        hyperParameterAngle = 0.35;//运动中运行方向偏差的最大角度
        hyperParameterDistance = 4;//避免碰撞的距离
        hyperParameterTurnSpeed = 2.0;//转向运动的速度
    } else if (worktable_array7.size() == 0) {
        hyperParameterTimeBuy = 1.0;
    }
    //工作台的格子被什么机器人占用,买卖后或更改目的地后要重置标准位
    if (robot1.product_type != 0) {//机器人卖,占用了该材料格
        if (robot1.worktableSelectionFlag != -1 &&
            robot1.worktableSelectionFlag != worktable1.worktableArrayIndex) {//如果机器人中途改变了目的地,需要将上一轮工作台设置的flag清除
            worktable_array[robot1.worktableSelectionFlag].raw_material_cell_robot[robot1.product_type] = -1;//上一轮的工作台下标是robot1.worktableSelectionFlag
            robot1.worktableSelectionFlag = worktable1.worktableArrayIndex;
            worktable1.raw_material_cell_robot[robot1.product_type] = robot1.robotId;
        } else {
            robot1.worktableSelectionFlag = worktable1.worktableArrayIndex;
            worktable1.raw_material_cell_robot[robot1.product_type] = robot1.robotId;
        }
    } else {//机器人买,占用了该产品格
        if (robot1.worktableSelectionFlag != -1 &&
            robot1.worktableSelectionFlag != worktable1.worktableArrayIndex) {//如果机器人中途改变了目的地,需要将上一轮工作台设置的flag清除
            worktable_array[robot1.worktableSelectionFlag].raw_material_cell_robot[0] = -1;//上一轮的工作台下标是robot1.worktableSelectionFlag
            robot1.worktableSelectionFlag = worktable1.worktableArrayIndex;
            worktable1.raw_material_cell_robot[0] = robot1.robotId;
        } else {
            robot1.worktableSelectionFlag = worktable1.worktableArrayIndex;
            worktable1.raw_material_cell_robot[0] = robot1.robotId;
        }
    }

    int minRobotIndex;//检测碰撞中用到
    double angleRobotOrientation;////也可以让他们提前分开,有可能会更好,通过碰撞预测代替夹角判断,这样应该也会更好
//    if (worktable_array7.size() == 0) {
//        if (distanceSquaredBetweenRobot(robot1, robot_array, minRobotIndex) <=
//            3 && minRobotIndex > robot1.robotId) {//如果没有货物的两个机器人撞在一起死锁,就把他们分开,
//            angleRobotOrientation = angleRobotBetweenOrientation(robot1.orientation,
//                                                                 robot_array[minRobotIndex].orientation);
//            if (angleRobotOrientation < hyperParameterAngleCollision) {//夹角小,有撞得可能
//
//                if (angleRobotBetweenOrientation(robot1.orientation - 0.005,
//                                                 robot_array[minRobotIndex].orientation) <
//                    angleRobotOrientation) {//如果顺时针转向后夹角变小,那就朝这个方向转,如果没有变小,就换个方向转
//                    printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
//                    printf("rotate %d %f\n", robot1.robotId, hyperParameterRobotAngle);
//                    printf("forward %d %d\n", minRobotIndex, hyperParameterSpeed);
//                    printf("rotate %d %f\n", minRobotIndex, hyperParameterRobotAngle);
//                    return true;
//                } else {
//                    printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
//                    printf("rotate %d %f\n", robot1.robotId, hyperParameterRobotAngle);
//                    printf("forward %d %d\n", minRobotIndex, hyperParameterSpeed);
//                    printf("rotate %d %f\n", minRobotIndex, hyperParameterRobotAngle);
//                    return true;
//                }
//            }
//        }
//    }

    if (distanceSquaredBetweenPoint(robot1, worktable1) >= 2) {//距离远,说明是赶路,赶路需要避开
        if (robot1.coordinate_y >= 49.4) {
            if (robot1.orientation >= 0 && robot1.orientation < 3.14 / 2) {//在上面,向右上移动,顺时针旋转
                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                printf("rotate %d %f\n", robot1.robotId, -3.14);
            } else if (robot1.orientation >= 3.14 / 2 && robot1.orientation < 3.14) {//在上面,向左上移动,逆时针旋转
                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                printf("rotate %d %f\n", robot1.robotId, 3.14);
            }
            return true;
        } else if (robot1.coordinate_x >= 49.4) {
            if (robot1.orientation >= 0 && robot1.orientation < 3.14 / 2) {//在右面,向右上移动,逆时针旋转
                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                printf("rotate %d %f\n", robot1.robotId, 3.14);
            } else if (robot1.orientation < 0 && robot1.orientation > -3.14 / 2) {//在右面,向右下移动,顺时针旋转
                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                printf("rotate %d %f\n", robot1.robotId, -3.14);
            }
            return true;
        } else if (robot1.coordinate_x < 0.6) {
            if (robot1.orientation < -3.14 / 2 && robot1.orientation >= -3.14) {//在左面,向左下移动,逆时针旋转
                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                printf("rotate %d %f\n", robot1.robotId, 3.14);
            } else if (robot1.orientation > 3.14 / 2 && robot1.orientation < 3.14) {//在左面,向左上移动,顺时针旋转
                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                printf("rotate %d %f\n", robot1.robotId, -3.14);
            }
            return true;
        } else if (robot1.coordinate_y < 0.6) {
            if (robot1.orientation <= -3.14 / 2 && robot1.orientation > -3.14) {//在下面,向左下移动,顺时针旋转
                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                printf("rotate %d %f\n", robot1.robotId, -3.14);
            } else if (robot1.orientation < 0 && robot1.orientation > -3.14 / 2) {//在下面,向右下移动,逆时针旋转
                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                printf("rotate %d %f\n", robot1.robotId, 3.14);
            }
            return true;
        }
    }

    if (robot1.worktable_id != worktable1.worktableArrayIndex) {//在不能买卖货的时候躲避,能卖货先卖货
        for (minRobotIndex = 0; minRobotIndex < robot_array.size(); minRobotIndex++) {
            int flagCollision = 1;
            if (minRobotIndex != robot1.robotId && minRobotIndex < robot1.robotId) {
//&&
//                (robot1.product_type != 0 || robot_array[minRobotIndex].product_type != 0)
                switch (coordinateTransform(robot1, robot_array[minRobotIndex], frameID)) {
                    case 0:
                        flagCollision = 0;
                        break;
                    case 1://一象限外半部分,角度在第三象限,双方都顺时针旋转
                        printf("forward %d %f\n", robot1.robotId, hyperParameterAvoidSpeed);
                        printf("rotate %d %f\n", robot1.robotId, (-1.0) * hyperParameterRobotAngle);
                        printf("forward %d %f\n", minRobotIndex, hyperParameterAvoidSpeed);
                        printf("rotate %d %f\n", minRobotIndex, (-1.0) * hyperParameterRobotAngle);
                        break;
                    case 2://一象限外半部分,角度在第四象限,不好办,这种方法会发生平行纠缠,一个走,一个停,货物贵的走(走的时候顺时针转),便宜的停
                        if (robot1.product_type > robot_array[minRobotIndex].product_type) {
                            printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                            printf("rotate %d %f\n", robot1.robotId, (-1.0) * hyperParameterRobotAngle);
                            printf("forward %d %f\n", minRobotIndex, 0);
                        } else {
                            printf("forward %d %d\n", minRobotIndex, hyperParameterSpeed);
                            printf("rotate %d %f\n", minRobotIndex, (-1.0) * hyperParameterRobotAngle);
                            printf("forward %d %f\n", robot1.robotId, 0);
                        }
                        break;
                    case 3://四象限外半部分,角度在第一象限,不好办,这种方法会发生平行纠缠,一个走,一个停,货物贵的走,走的时候要拐弯,便宜的停
                        if (robot1.product_type > robot_array[minRobotIndex].product_type) {
                            printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                            printf("rotate %d %f\n", robot1.robotId, hyperParameterRobotAngle);
                            printf("forward %d %f\n", minRobotIndex, 0);
                        } else {
                            printf("forward %d %d\n", minRobotIndex, hyperParameterSpeed);
                            printf("rotate %d %f\n", minRobotIndex, hyperParameterRobotAngle);
                            printf("forward %d %f\n", robot1.robotId, 0);
                        }
                        break;
                    case 4://四象限外半部分,角度在第二象限,双方都逆时针旋转
                        printf("forward %d %f\n", robot1.robotId, hyperParameterAvoidSpeed);
                        printf("rotate %d %f\n", robot1.robotId, hyperParameterRobotAngle);
                        printf("forward %d %f\n", minRobotIndex, hyperParameterAvoidSpeed);
                        printf("rotate %d %f\n", minRobotIndex, hyperParameterRobotAngle);
                        break;
                    case 5://一象限内半部分,角度在第四象限,不好办,停下同时给对方让出空间,等对方走,让不出多少空间,还是得有一点速度.
                        printf("forward %d %f\n", robot1.robotId, 1.0);
                        printf("rotate %d %f\n", robot1.robotId, (-1.0) * hyperParameterRobotAngle);
                        break;
                    case 6://四象限内半部分,角度在第一象限,不好办,停下等对方走,让不出多少空间,还是得有一点速度.
                        printf("forward %d %f\n", robot1.robotId, 1.0);
                        printf("rotate %d %f\n", robot1.robotId, hyperParameterRobotAngle);
                        break;
                    case 7://四象限内半部分,角度在第二象限,双方都逆时针旋转
                        printf("forward %d %f\n", robot1.robotId, hyperParameterAvoidSpeed);
                        printf("rotate %d %f\n", robot1.robotId, hyperParameterRobotAngle);
                        printf("forward %d %f\n", minRobotIndex, hyperParameterAvoidSpeed);
                        printf("rotate %d %f\n", minRobotIndex, hyperParameterRobotAngle);
                        break;
                    case 8://一象限内半部分,角度在第三象限,双方都逆时针旋转
                        printf("forward %d %f\n", robot1.robotId, hyperParameterAvoidSpeed);
                        printf("rotate %d %f\n", robot1.robotId, (-1.0) * hyperParameterRobotAngle);
                        printf("forward %d %f\n", minRobotIndex, hyperParameterAvoidSpeed);
                        printf("rotate %d %f\n", minRobotIndex, (-1.0) * hyperParameterRobotAngle);
                        break;
                    case 9://一象限内半部分,在靠近y轴的正半轴,对方减速,自己冲过去.//
                        printf("forward %d %d\n", robot1.robotId, 6);
                        printf("forward %d %f\n", minRobotIndex, 1.0);
                        break;
                    case 10://四象限内半部分,在靠近y轴的负半轴,对方减速,自己冲过去.//
                        printf("forward %d %d\n", robot1.robotId, 6);
                        printf("forward %d %f\n", minRobotIndex, 1.0);
                        break;
                }
                if (flagCollision == 1)
                    return true;
            }
        }
    }


    robot1.destinationDistance_x = worktable1.coordinate_x - robot1.coordinate_x;//计算目的地距离
    robot1.destinationDistance_y = worktable1.coordinate_y - robot1.coordinate_y;
    //distanceLength距离
    double distanceLength = sqrt(robot1.destinationDistance_x * robot1.destinationDistance_x +
                                 robot1.destinationDistance_y * robot1.destinationDistance_y);
    double angleOrientation_DirectionDestination;//朝向与目的地方向的夹角
    if (robot1.worktable_id != worktable1.worktableArrayIndex) {//没有到,就去目的地
        double cosTheta = robot1.destinationDistance_x / distanceLength;
        angleOrientation_DirectionDestination = acos(cosTheta);//返回arg的反余弦值cos-1(x)，值域为[0,pi],其中变元范围[-1,1]。
        if (robot1.destinationDistance_y < 0)//因为y小于0,应该是相反数.
            angleOrientation_DirectionDestination = angleOrientation_DirectionDestination * (-1.0);
        if (angleOrientation_DirectionDestination * robot1.orientation > 0) {//同号
            if (fabs(angleOrientation_DirectionDestination - robot1.orientation) >
                hyperParameterAngle) {//角度偏差过大,停车,直接方向盘打死
                if (robot1.orientation > angleOrientation_DirectionDestination) {//顺时针转
                    if (distanceSquaredBetweenPoint(robot1, worktable1) <= hyperParameterDistance) {//距离较近时,调整方向为主,
                        printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                        printf("rotate %d %f\n", robot1.robotId, -3.14);
                    } else {//距离较远时,行动为主
                        if (robot1.coordinate_x > 45 || robot1.coordinate_y > 45 || robot1.coordinate_x < 5 ||
                            robot1.coordinate_y < 5) {//距离边界太进,以调头为主
                            printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                            printf("rotate %d %f\n", robot1.robotId, -3.14);
                        } else if (fabs(angleOrientation_DirectionDestination - robot1.orientation) >
                                   3.14 * 5.0 / 6.0) {//角度偏差太大,以调头为主
                            printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                            printf("rotate %d %f\n", robot1.robotId, -3.14);
                        } else {
                            printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                            printf("rotate %d %f\n", robot1.robotId, -3.14);
                        }
                    }
                    fflush(stdout);
                    return false;
                } else {//逆时针转
                    if (distanceSquaredBetweenPoint(robot1, worktable1) <= hyperParameterDistance) {//距离较近时,调整方向为主,
                        printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                        printf("rotate %d %f\n", robot1.robotId, 3.14);
                    } else {//距离较远时,行动为主
                        if (robot1.coordinate_x > 45 || robot1.coordinate_y > 45 || robot1.coordinate_x < 5 ||
                            robot1.coordinate_y < 5) {//距离边界太进,以调头为主
                            printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                            printf("rotate %d %f\n", robot1.robotId, 3.14);
                        } else if (fabs(angleOrientation_DirectionDestination - robot1.orientation) >
                                   3.14 * 5.0 / 6.0) {//角度偏差太大,以调头为主
                            printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                            printf("rotate %d %f\n", robot1.robotId, 3.14);
                        } else {
                            printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                            printf("rotate %d %f\n", robot1.robotId, 3.14);
                        }
                    }
                    fflush(stdout);
                    return true;
                }
            } else {//角度偏差小,直接跑
                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                printf("rotate %d %f\n", robot1.robotId, 0);
                fflush(stdout);
                return true;
            }
        } else {//异号,计算夹角比较麻烦,有两种情况,需要考虑所在象限
            if (fabs(angleOrientation_DirectionDestination - robot1.orientation) > 3.141592653) {
                if ((2 * 3.141592653 - fabs(angleOrientation_DirectionDestination - robot1.orientation)) >
                    hyperParameterAngle) {//角度偏差过大,停车,直接方向盘打死
                    if (robot1.orientation < angleOrientation_DirectionDestination) {//顺时针转
                        if (distanceSquaredBetweenPoint(robot1, worktable1) <= hyperParameterDistance) {//距离较近时,调整方向为主,
                            printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                            printf("rotate %d %f\n", robot1.robotId, -3.14);
                        } else {//距离较远时,行动为主
                            if (robot1.coordinate_x > 45 || robot1.coordinate_y > 45 || robot1.coordinate_x < 5 ||
                                robot1.coordinate_y < 5) {//距离边界太进,以调头为主
                                printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                                printf("rotate %d %f\n", robot1.robotId, -3.14);
                            } else if (fabs(angleOrientation_DirectionDestination - robot1.orientation) >
                                       3.14 * 5.0 / 6.0) {//角度偏差太大,以调头为主
                                printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                                printf("rotate %d %f\n", robot1.robotId, -3.14);
                            } else {
                                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                                printf("rotate %d %f\n", robot1.robotId, -3.14);
                            }
                        }
                        fflush(stdout);
                        return true;
                    } else {//逆时针转
                        if (distanceSquaredBetweenPoint(robot1, worktable1) <= hyperParameterDistance) {//距离较近时,调整方向为主,
                            printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                            printf("rotate %d %f\n", robot1.robotId, 3.14);
                        } else {//距离较远时,行动为主
                            if (robot1.coordinate_x > 45 || robot1.coordinate_y > 45 || robot1.coordinate_x < 5 ||
                                robot1.coordinate_y < 5) {//距离边界太进,以调头为主
                                printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                                printf("rotate %d %f\n", robot1.robotId, 3.14);
                            } else if (fabs(angleOrientation_DirectionDestination - robot1.orientation) >
                                       3.14 * 5.0 / 6.0) {//角度偏差太大,以调头为主
                                printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                                printf("rotate %d %f\n", robot1.robotId, 3.14);
                            } else {
                                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                                printf("rotate %d %f\n", robot1.robotId, 3.14);
                            }
                        }
                        fflush(stdout);
                        return true;
                    }
                } else {//角度偏差小,直接跑
                    printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                    printf("rotate %d %f\n", robot1.robotId, 0);
                    fflush(stdout);
                    return true;
                }
            } else {//
                if (fabs(angleOrientation_DirectionDestination - robot1.orientation) >
                    hyperParameterAngle) {//角度偏差过大,停车,直接方向盘打死
                    if (robot1.orientation > angleOrientation_DirectionDestination) {//顺时针转
                        if (distanceSquaredBetweenPoint(robot1, worktable1) <= hyperParameterDistance) {//距离较近时,调整方向为主,
                            printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                            printf("rotate %d %f\n", robot1.robotId, -3.14);
                        } else {//距离较远时,行动为主
                            if (robot1.coordinate_x > 45 || robot1.coordinate_y > 45 || robot1.coordinate_x < 5 ||
                                robot1.coordinate_y < 5) {//距离边界太进,以调头为主
                                printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                                printf("rotate %d %f\n", robot1.robotId, -3.14);
                            } else if (fabs(angleOrientation_DirectionDestination - robot1.orientation) >
                                       3.14 * 5.0 / 6.0) {//角度偏差太大,以调头为主
                                printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                                printf("rotate %d %f\n", robot1.robotId, -3.14);
                            } else {
                                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                                printf("rotate %d %f\n", robot1.robotId, -3.14);
                            }
                        }
                        fflush(stdout);
                        return true;
                    } else {//逆时针转
                        if (distanceSquaredBetweenPoint(robot1, worktable1) <= hyperParameterDistance) {//距离较近时,调整方向为主,
                            printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                            printf("rotate %d %f\n", robot1.robotId, 3.14);
                        } else {//距离较远时,行动为主
                            if (robot1.coordinate_x > 45 || robot1.coordinate_y > 45 || robot1.coordinate_x < 5 ||
                                robot1.coordinate_y < 5) {//距离边界太进,以调头为主
                                printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                                printf("rotate %d %f\n", robot1.robotId, 3.14);
                            } else if (fabs(angleOrientation_DirectionDestination - robot1.orientation) >
                                       3.14 * 5.0 / 6.0) {//角度偏差太大,以调头为主
                                printf("forward %d %f\n", robot1.robotId, hyperParameterTurnSpeed);
                                printf("rotate %d %f\n", robot1.robotId, 3.14);
                            } else {
                                printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                                printf("rotate %d %f\n", robot1.robotId, 3.14);
                            }
                        }
                        fflush(stdout);
                        return true;
                    }
                } else {//角度偏差小,直接跑
                    printf("forward %d %d\n", robot1.robotId, hyperParameterSpeed);
                    printf("rotate %d %f\n", robot1.robotId, 0);
                    fflush(stdout);
                    return true;
                }
            }
        }
    } else {//到了买或卖东西
        if (robot1.product_type == 0) {
            robot1.worktableSelectionFlag = -1;
            worktable1.raw_material_cell_robot[0] = -1;
            printf("buy %d\n", robot1.robotId);
            fflush(stdout);
            return true;
        } else {
            robot1.worktableSelectionFlag = -1;//处理了业务,机器人不在占用工作台
            worktable1.raw_material_cell_robot[robot1.product_type] = -1;//卖了东西,工作台的产品格不占用
            printf("sell %d\n", robot1.robotId);
            fflush(stdout);
            return true;
        }
    }
}

/**
 * 计算工作台之间的距离
 * @param worktable1 工作台1
 * @param worktable2 工作台2
 * @return 工作台1与工作台2的距离的平方
 */
double distanceSquaredBetweenWorktable(worktable &worktable1, worktable &worktable2) {//计算二点距离的平方
    double destinationDistance_x = worktable1.coordinate_x - worktable2.coordinate_x;//计算目的地距离
    double destinationDistance_y = worktable1.coordinate_y - worktable2.coordinate_y;
    //distanceLength距离
    double distanceLength = destinationDistance_x * destinationDistance_x +
                            destinationDistance_y * destinationDistance_y;
    return distanceLength;
}

/**
 * productPriority物品优先级,记录在某帧时,该物品的优先级.优先级由赚钱速度(该物品利润/获得利润所花时间)决定,计算方式为 该物品利润/获得利润所需走的路程
 * 所需走路程为机器人到工作台id=minWorktableIndex的距离+工作台id=minWorktableIndex的距离到工作台id=minWorktableSellIndex的距离
 * priority             浮点数     存储该种物品的优先级
 * minWorktableIndex    整数      买该物品的工作台id
 * profit               浮点数     范围[3000,29000],该物品的利润
 * minWorktableSellIndex 整数     卖该物品的工作台id
 */
typedef struct productPriority {
    double priority = 0;//利润除以距离,利润高距离短的工作台优先选择
    int minWorktableIndex;//如果选择这个产品就选择这个工作台
    double profit;//买卖得到的利润
    int minWorktableSellIndex;//如果选择这个工作台minWorktableIndex买,就选择这个工作台卖
} productPriority;

/**
 * 计算机器人robotId距离哪个工作台最近,在考虑7号物品的生产的代码和销售物品的代码中用到
 * @param worktableIndexArray 工作台id的数组,存储多个工作台id
 * @param worktable_array  工作台数组,存储所有的工作台数据
 * @param robot_array 机器人数组,存储所有的机器人数据
 * @param robotId 机器人id
 * @param minDistance 最短距离的平方
 * @param minWorktableIndex 距离机器人robotId最近的工作台id
 * 通过& 返回最短距离的平方minDistance, 返回距离机器人robotId最近的工作台id=minWorktableIndex
 */
void
findShortestDistance(vector<int> &worktableIndexArray, vector<worktable> &worktable_array, vector<robot> &robot_array,
                     int &robotId, double &minDistance, int &minWorktableIndex) {
    double distanceBetween;
    minDistance = 9999999.9;
    for (int index = 0; index < worktableIndexArray.size(); index++) {//计算最短距离
        distanceBetween = distanceSquaredBetweenPoint(robot_array[robotId],
                                                      worktable_array[worktableIndexArray[index]]);
        if (minDistance > distanceBetween) {
            minDistance = distanceBetween;
            minWorktableIndex = worktableIndexArray[index];
        }
    }
}

/**
 * 计算卖物品的优先级
 * @param worktableIndexArray 待选择的售卖工作台
 * @param worktable_array
 * @param robot_array
 * @param robotId
 * @param minDistance 无用
 * @param minWorktableIndex 返回要去的工作台
 * @param productPriorityArray
 * @param worktable_array7
 */
void
findMaxPrioritySellWorktable(vector<int> &worktableIndexArray, vector<worktable> &worktable_array,
                             vector<robot> &robot_array,
                             int &robotId, double &minDistance, int &minWorktableIndex,
                             vector<productPriority> &productPriorityArray, vector<worktable> &worktable_array7) {
    double distanceBetween, priority;
    double maxPriority = 0;
    for (int index = 0; index < worktableIndexArray.size(); index++) {//计算最短距离
        distanceBetween = distanceSquaredBetweenPoint(robot_array[robotId],
                                                      worktable_array[worktableIndexArray[index]]);

        //priority = productPriorityArray[robot_array[robotId].product_type - 1].profit / sqrt(distanceBetween);

        if (worktable_array[worktableIndexArray[index]].worktable_type >= 4 &&
            worktable_array[worktableIndexArray[index]].worktable_type <= 6) {//如果卖给456
            if (worktable_array[worktableIndexArray[index]].remainingProductionTime ==
                -1) {//剩余生产时间等于-1,说明没有生产,说明非常需要该物品,为优先级进行加成
                //考虑是否影响到7
                int i;
                for (i = 0; i < worktable_array7.size(); i++) {
                    if (worktable_array[worktable_array7[i].worktableArrayIndex].remainingProductionTime == -1) {//未生产
                        if (worktable_array[worktable_array7[i].worktableArrayIndex].raw_material_cell[worktable_array[worktableIndexArray[index]].worktable_type] ==
                            '0') {
                            if (worktable_array[worktableIndexArray[index]].worktable_type == 4 &&
                                worktable_array[worktable_array7[i].worktableArrayIndex].rawMaterialCellState == 96) {
                                if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {//说明缺两种
                                    priority = (71400 - 14200 - 14900) / 4.0 /
                                               sqrt(distanceBetween);
                                } else {
                                    priority = ((71400 - 14200 - 14900) / 4.0 * 3.0 - 3200) / 2.0 /
                                               sqrt(distanceBetween);
                                }
                            } else if (worktable_array[worktableIndexArray[index]].worktable_type == 5 &&
                                       worktable_array[worktable_array7[i].worktableArrayIndex].rawMaterialCellState ==
                                       80) {
                                if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {//说明缺两种
                                    priority = (71400 - 13300 - 14900) / 4.0 /
                                               sqrt(distanceBetween);
                                } else {
                                    priority = ((71400 - 13300 - 14900) / 4.0 * 3.0 - 3200) / 2.0 /
                                               sqrt(distanceBetween);
                                }
                            } else if (worktable_array[worktableIndexArray[index]].worktable_type == 6 &&
                                       worktable_array[worktable_array7[i].worktableArrayIndex].rawMaterialCellState ==
                                       48) {
                                if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {//说明缺两种
                                    priority = (71400 - 13300 - 14900) / 4.0 /
                                               sqrt(distanceBetween);
                                } else {
                                    priority = ((71400 - 13300 - 14900) / 4.0 * 3.0 - 3200) / 2.0 /
                                               sqrt(distanceBetween);
                                }
                            } else if (worktable_array[worktable_array7[i].worktableArrayIndex].rawMaterialCellState ==
                                       0) {
                                if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {//说明缺两种
                                    priority = 71400.0 / (6 + 3 + 1) /
                                               sqrt(distanceBetween);
                                } else {
                                    priority = (71400.0 / (6 + 3 + 1) * 3.0 - 3200) / 2.0 /
                                               sqrt(distanceBetween);
                                }
                            } else {
                                if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {//说明缺两种
                                    priority = (71400 - 14200) / 7.0 /
                                               sqrt(distanceBetween);
                                } else {
                                    priority = ((71400 - 14200) / 7.0 * 3.0 - 3200) / 2.0 /
                                               sqrt(distanceBetween);
                                }
                            }
                            break;
                        }
                    }
                }
                if (i == worktable_array7.size()) {//如果没有获得7的加成,那就只能获得物品4物品5物品6的加成,
                    // 判断的方法是是否有break,如果break,那index不等于worktable_array7.size()
                    if (worktable_array[worktableIndexArray[index]].worktable_type == 4) {
                        if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {//说明缺两种
                            priority = (3000 + 3200 + 7100) / 3.0 /
                                       sqrt(distanceBetween);
                        } else {
                            priority = (3100 + 7100) /
                                       sqrt(distanceBetween);
                        }
                    } else if (worktable_array[worktableIndexArray[index]].worktable_type == 5) {
                        if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {//说明缺两种
                            priority = (3000 + 3400 + 7800) / 3.0 /
                                       sqrt(distanceBetween);
                        } else {
                            priority = (3200 + 7800) /
                                       sqrt(distanceBetween);
                        }
                    } else if (worktable_array[worktableIndexArray[index]].worktable_type == 6) {
                        if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {//说明缺两种
                            priority = (3200 + 3400 + 7800) / 3.0 /
                                       sqrt(distanceBetween);
                        } else {
                            priority = (3300 + 7800) /
                                       sqrt(distanceBetween);
                        }
                    }
                }


//                if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {
//                    priority += (productPriorityArray[worktable_array[worktableIndexArray[index]].worktable_type -
//                                                      1].profit / sqrt(distanceBetween)) * 0.25;
//                } else {
//                    priority +=
//                            (productPriorityArray[worktable_array[worktableIndexArray[index]].worktable_type -
//                                                  1].profit /
//                             sqrt(distanceBetween)) * 0.25 * 4;
//                }
            } else {//如果在生产,那将没有优先级加成
                priority = productPriorityArray[robot_array[robotId].product_type - 1].profit / sqrt(distanceBetween);
            }

//            for (int i = 0; i < worktable_array7.size(); i++) {//遍历数组中所有的7号工作台
//                if (worktable_array[worktable_array7[i].worktableArrayIndex].remainingProductionTime ==
//                    -1) {//处于未生产状态中
//                    if (worktable_array[worktable_array7[i].worktableArrayIndex].raw_material_cell[worktable_array[worktableIndexArray[index]].worktable_type] ==
//                        '0') {
//                        //如果7号生产需要该物品,那就再加成
//                        //设买卖7号的优先值为29000.0/75.0,因为生产销售各占50%,生产需要3件,故为1/6,7号二缺一在原来加成的基础上加成50%;
//                        if (worktable_array[worktableIndexArray[index]].worktable_type == 4 &&
//                            worktable_array[worktable_array7[i].worktableArrayIndex].rawMaterialCellState == 96) {
//                            priority += 2 * (29000.0 / 75.0) / 12.0;
//                        } else if (worktable_array[worktableIndexArray[index]].worktable_type == 5 &&
//                                   worktable_array[worktable_array7[i].worktableArrayIndex].rawMaterialCellState ==
//                                   80) {
//                            priority += 2 * (29000.0 / 75.0) / 12.0;
//                        } else if (worktable_array[worktableIndexArray[index]].worktable_type == 6 &&
//                                   worktable_array[worktable_array7[i].worktableArrayIndex].rawMaterialCellState ==
//                                   48) {
//                            priority += 2 * (29000.0 / 75.0) / 12.0;
//                        } else {
//                            priority += (29000.0 / 75.0) / 12.0;
//                        }
//                        break;
//                    }
//                }
//            }
        } else if (worktable_array[worktableIndexArray[index]].worktable_type == 7) {
            if (worktable_array[worktableIndexArray[index]].remainingProductionTime ==
                -1) {//剩余生产时间等于-1,说明没有生产,说明非常需要该物品,为优先级进行加成
                if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 0) {//缺三个
                    priority = (71400 / (6 + 3 + 1) * 3.0 - 6400) / sqrt(distanceBetween);
//                    priority += 2 * (29000.0 / sqrt(distanceBetween)) / 6.0;
                } else if (worktable_array[worktableIndexArray[index]].rawMaterialCellState == 48 ||
                           worktable_array[worktableIndexArray[index]].rawMaterialCellState == 80 ||
                           worktable_array[worktableIndexArray[index]].rawMaterialCellState == 96) {//缺一个
                    priority = ((71400 - 14900 - 13300) / 4.0 * 3.0 - 3400 - 3000) / sqrt(distanceBetween);
//                    priority += 6 * (29000.0 / sqrt(distanceBetween)) / 6.0;
                } else {
                    priority = ((71400 - 14900) / 7.0 * 3.0 - 3000 - 3200) / sqrt(distanceBetween);
//                    priority += 4 * (29000.0 / sqrt(distanceBetween)) / 6.0;
                }
            } else {
                priority = productPriorityArray[robot_array[robotId].product_type - 1].profit / sqrt(distanceBetween);
            }
        } else {
            priority = productPriorityArray[robot_array[robotId].product_type - 1].profit / sqrt(distanceBetween);
        }
        if (priority > maxPriority) {
            maxPriority = priority;
            minWorktableIndex = worktableIndexArray[index];
        }
    }
}

/**
 * 寻找距离工作台worktable1最近的工作台,在优先销售7的代码的判断时间是否充足部分中用到该函数
 * @param worktableIndexSellArray 工作台id数组,存储在当前帧能收购工作台1生产的物品的工作台的id
 * @param worktable_array 工作台数组,存储所有工作台的信息
 * @param worktable1 工作台1
 * @return 距离工作台worktable1最近的工作台
 */
int findShortestSellDistance(vector<int> &worktableIndexSellArray, vector<worktable> &worktable_array,
                             worktable worktable1) {//寻找距离worktable1最近的工作台
    double distanceBetween, minDistance = 9999999.9;
    int minWorktableIndex = 0;
    for (int j = 0; j < worktableIndexSellArray.size(); j++) {
        if (worktableIndexSellArray[j] >= 0) {
            distanceBetween = distanceSquaredBetweenWorktable(worktable1,
                                                              worktable_array[worktableIndexSellArray[j]]);
            if (minDistance > distanceBetween) {
                minDistance = distanceBetween;
                minWorktableIndex = j;
            }
        }
    }
    return minWorktableIndex;
}

/**
 * 计算最短距离和,函数用于计算优先级
 * @param worktableIndexBuyArray 工作台id数组,存储在当前帧,能被机器人robotId所选择并且成品格有物品i的所有工作台的id.(该工作台的产品格有物品i,并且没有其他机器人标记该产品格)
 * @param worktableIndexSellArray 工作台id数组,存储在当前帧,能收购物品i的所有工作台的id(物品对应的该工作台的原材料格是空的,并且没有其他机器人标记该原材料格)
 * @param worktable_array 工作台数组,存储所有工作台信息
 * @param robot_array 机器人数组,存储所有机器人信息
 * @param robotId 机器人id
 * @param minDistance 存储最短距离和,和为机器人到工作台id=minWorktableIndex的距离平方+工作台id=minWorktableIndex的距离到工作台id=minWorktableSellIndex的距离平方
 * @param minWorktableIndex 买该物品的工作台id
 * @param minWorktableSellIndex 卖该物品的工作台id
 * 通过& 返回距离和minDistance,买物品的工作台id=minWorktableIndex,卖物品的工作台id=minWorktableSellIndex
 */
void
findShortestBuyDistance(vector<int> &worktableIndexBuyArray, vector<int> &worktableIndexSellArray,
                        vector<worktable> &worktable_array, vector<robot> &robot_array,
                        int &robotId, double &minDistance, int &minWorktableIndex,
                        int &minWorktableSellIndex) {//寻找最近的买卖距离和
    double distanceBetween, distanceBetweenPoint;
    minDistance = 9999999.9;
    int i, j;
    for (i = 0; i < worktableIndexBuyArray.size(); i++) {
        distanceBetweenPoint = distanceSquaredBetweenPoint(robot_array[robotId],
                                                           worktable_array[worktableIndexBuyArray[i]]);
        for (j = 0; j < worktableIndexSellArray.size(); j++) {
            distanceBetween = distanceBetweenPoint
                              +
                              distanceSquaredBetweenWorktable(worktable_array[worktableIndexBuyArray[i]],
                                                              worktable_array[worktableIndexSellArray[j]]);
            if (minDistance > distanceBetween) {//如果是最短路径,记录距离和走过的两个结点
                minDistance = distanceBetween;
                minWorktableSellIndex = worktableIndexSellArray[j];
                minWorktableIndex = worktableIndexBuyArray[i];
            }
        }
    }
}

/**
 * 物品worktable_type够了返回true,不够返回false
 * @param worktable_array
 * @param worktable_type
 * @return
 */
bool isItemEnough(vector<worktable> &worktable_array, int worktable_type) {
    int sumSupply = 0;//统计供给和
    int sumDemand = 0;//统计需求和
    int i;
    for (i = 0; i < worktable_array.size(); i++) {
        if (worktable_array[i].worktable_type == worktable_type) {
            if (worktable_array[i].remainingProductionTime != -1 ||
                worktable_array[i].productCellStatus == 1) {//说明在生产或者有了产品
                sumSupply++;//统计供给和
            }
        }
        if (worktable_array[i].worktable_type == 7) {
            if (worktable_array[i].raw_material_cell[worktable_type] == '0') {//7号工作台缺该物品
                sumDemand++;//统计需求和
            }
        }
    }
    if (sumSupply >= sumDemand) {//如果供给大于等于需求,那就不需要供给,
        return true;
    } else {
        return false;
    }
}


/**
 * 计算买物品的优先级,函数用于计算优先级
 * @param worktableIndexBuyArray 工作台id数组,存储在当前帧,能被机器人robotId所选择并且成品格有物品i的所有工作台的id.(该工作台的产品格有物品i,并且没有其他机器人标记该产品格)
 * @param worktableIndexSellArray 工作台id数组,存储在当前帧,能收购物品i的所有工作台的id(物品对应的该工作台的原材料格是空的,并且没有其他机器人标记该原材料格)
 * @param worktable_array 工作台数组,存储所有工作台信息
 * @param robot_array 机器人数组,存储所有机器人信息
 * @param robotId 机器人id
 * @param minDistance 存储最短距离和,和为机器人到工作台id=minWorktableIndex的距离平方+工作台id=minWorktableIndex的距离到工作台id=minWorktableSellIndex的距离平方
 * @param minWorktableIndex 买该物品的工作台id
 * @param minWorktableSellIndex 卖该物品的工作台id
 * @param productPriorityArray 存储每种物品的优先级
 * @param itemId 物品号-1
 * @param worktable_array7 存储所有7号工作台
 * 通过& 返回距离和minDistance,买物品的工作台id=minWorktableIndex,卖物品的工作台id=minWorktableSellIndex,该物品的优先级priority
 */
void
findMaxPriority(vector<int> &worktableIndexBuyArray, vector<int> &worktableIndexSellArray,
                vector<worktable> &worktable_array, vector<robot> &robot_array,
                int &robotId, double &minDistance, int &minWorktableIndex,
                int &minWorktableSellIndex, vector<productPriority> &productPriorityArray, int &itemId,
                vector<worktable> &worktable_array7, int &frameID) {//寻找最近的买卖距离和
    double distanceBetween, distanceBetweenPoint, priority;
    double maxPriority = 0;
    int i, j;
    if (worktable_array7.size() > 2) {//专门处理心形
        for (i = 0; i < worktableIndexBuyArray.size(); i++) {
            distanceBetweenPoint = distanceSquaredBetweenPoint(robot_array[robotId],
                                                               worktable_array[worktableIndexBuyArray[i]]);
            priority = 1000.0 / distanceBetweenPoint;
            if (maxPriority < priority) {//如果是最短路径,记录距离和走过的两个结点
                maxPriority = priority;
                minWorktableIndex = worktableIndexBuyArray[i];
            }
        }
        if (worktable_array[minWorktableIndex].worktable_type >= 4 &&
            worktable_array[minWorktableIndex].worktable_type <= 6) {//如果卖给7号
            maxPriority = 0;
            for (j = 0; j < worktableIndexSellArray.size(); j++) {
                if (worktable_array[worktableIndexSellArray[j]].worktable_type ==
                    7) {//不区分是否在生产,选择缺原材料少的工作台
                    if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState == 0) {//缺三种
                        distanceBetween = 10000;
                    } else if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                               48 ||
                               worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                               80 ||
                               worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                               96) {//缺一种,取了中间值
                        distanceBetween = 30000;
                    } else {//缺两种,取了中间值
                        distanceBetween = 20000;
                    }
                }
                if (maxPriority < distanceBetween) {//记录下缺原材料最少的工作台
                    maxPriority = distanceBetween;
                    minWorktableSellIndex = worktableIndexSellArray[j];
                }
            }
        } else {//如果卖给456或89,选择最近的
            for (j = 0; j < worktableIndexSellArray.size(); j++) {
                distanceBetween = distanceSquaredBetweenWorktable(worktable_array[minWorktableIndex],
                                                                  worktable_array[worktableIndexSellArray[j]]);
                if (minDistance > distanceBetween) {
                    minDistance = distanceBetween;
                    minWorktableSellIndex = worktableIndexSellArray[j];
                }
            }
        }
        productPriorityArray[itemId].priority = maxPriority;
        productPriorityArray[itemId].minWorktableIndex = minWorktableIndex;
        productPriorityArray[itemId].minWorktableSellIndex = minWorktableSellIndex;

//        //test
//        fprintf(stderr,
//                "frameID %d robot[%d] buy[%.2f][%.2f]. sell[%.2f][%.2f] d1 %.2f d2 %.2f priority %.2f \n",
//                frameID, robotId,
//                worktable_array[worktableIndexBuyArray[i]].coordinate_x,
//                worktable_array[worktableIndexBuyArray[i]].coordinate_y,
//                worktable_array[worktableIndexSellArray[j]].coordinate_x,
//                worktable_array[worktableIndexSellArray[j]].coordinate_y,
//                sqrt(distanceBetweenPoint),
//                sqrt(distanceBetween), priority
//        );//买卖物品产生的优先级);
        return;
    }
    for (i = 0; i < worktableIndexBuyArray.size(); i++) {
        distanceBetweenPoint = distanceSquaredBetweenPoint(robot_array[robotId],
                                                           worktable_array[worktableIndexBuyArray[i]]);
        for (j = 0; j < worktableIndexSellArray.size(); j++) {

            distanceBetween = distanceSquaredBetweenWorktable(worktable_array[worktableIndexBuyArray[i]],
                                                              worktable_array[worktableIndexSellArray[j]]);
//            priority = productPriorityArray[itemId].profit /
//                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));//买卖物品产生的优先级
            if (worktable_array[worktableIndexSellArray[j]].worktable_type >= 4 &&
                worktable_array[worktableIndexSellArray[j]].worktable_type <= 6) {//如果卖给456
                if (worktable_array[worktableIndexSellArray[j]].worktable_type == 4 &&
                    worktable_array7.size() == 1&&frameID<7321) {//箭头形
                    priority = 99999999 /
                               (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                } else {
                    if (worktable_array[worktableIndexSellArray[j]].remainingProductionTime ==
                        -1) {
                        //剩余生产时间等于-1,说明没有生产,说明非常需要该物品,为优先级进行加成,
                        //如果对7有影响,再进行加成,首先遍历所有7工作台
                        //看有没有7号工作台是否未生产
                        //需要待合成的物品,如果需要物品并且没有机器人去送该物品的话,
                        //那就分成三种情况讨论,分别是7号缺三种,7号缺两种,7号缺一种.
                        //每种情况又可以分为两种情况,分别是待合成物品需要的原材料有两种,有一种.计算优先权后break.
                        int index;
                        for (index = 0; index < worktable_array7.size(); index++) {//遍历数组中所有的7号工作台
                            if (worktable_array[worktable_array7[index].worktableArrayIndex].remainingProductionTime ==
                                -1) {//处于未生产状态中,说明需要材料
                                //如果所有7号生产需要该物品x个,并且没有地图没有x个该物品,那就再加成
                                if (!isItemEnough(worktable_array,
                                                  worktable_array[worktableIndexSellArray[j]].worktable_type) &&
                                    worktable_array[worktable_array7[index].worktableArrayIndex].raw_material_cell[worktable_array[worktableIndexSellArray[j]].worktable_type] ==
                                    '0') {
                                    //如果这个7号生产需要该物品,那就再加成
                                    if (worktable_array[worktableIndexSellArray[j]].worktable_type == 4 &&
                                        worktable_array[worktable_array7[index].worktableArrayIndex].rawMaterialCellState ==
                                        96) {//7号二缺一,缺4,减去物品5的和14200与物品6的和14900
                                        if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                                            0) {//说明缺两种
                                            priority = (71400 - 14200 - 14900) / 4.0 /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        } else {
                                            priority = ((71400 - 14200 - 14900) / 4.0 * 3.0 - 3200) / 2.0 /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        }
                                    } else if (worktable_array[worktableIndexSellArray[j]].worktable_type == 5 &&
                                               worktable_array[worktable_array7[index].worktableArrayIndex].rawMaterialCellState ==
                                               80) {//7号二缺一,缺5,减去物品4的和13300与物品6的和14900
                                        if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                                            0) {//说明缺两种
                                            priority = (71400 - 13300 - 14900) / 4.0 /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        } else {
                                            priority = ((71400 - 13300 - 14900) / 4.0 * 3.0 - 3200) / 2.0 /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        }
                                    } else if (worktable_array[worktableIndexSellArray[j]].worktable_type == 6 &&
                                               worktable_array[worktable_array7[index].worktableArrayIndex].rawMaterialCellState ==
                                               48) {//7号二缺一,缺6,减去物品4的和13300与物品5的和14200
                                        if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                                            0) {//说明缺两种
                                            priority = (71400 - 13300 - 14900) / 4.0 /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        } else {
                                            priority = ((71400 - 13300 - 14900) / 4.0 * 3.0 - 3200) / 2.0 /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        }
                                    } else if (
                                            worktable_array[worktable_array7[index].worktableArrayIndex].rawMaterialCellState ==
                                            0) {//7号缺三种
                                        if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                                            0) {//说明缺两种
                                            priority = 71400.0 / (6 + 3 + 1) /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        } else {
                                            priority = (71400.0 / (6 + 3 + 1) * 3.0 - 3200) / 2.0 /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        }
                                    } else {//7号缺两种,因为缺两种的计算太复杂了,直接用中位数来代替
                                        if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                                            0) {//说明缺两种
                                            priority = (71400 - 14200) / 7.0 /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        } else {
                                            priority = ((71400 - 14200) / 7.0 * 3.0 - 3200) / 2.0 /
                                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if (index ==
                            worktable_array7.size()) {//如果没有获得7的加成,那就只能获得物品4物品5物品6的加成,判断的方法是是否有break,如果break,那index不等于worktable_array7.size()
                            if (worktable_array[worktableIndexSellArray[j]].worktable_type == 4) {
                                if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState == 0) {//说明缺两种
                                    priority = (3000 + 3200 + 7100) / 3.0 /
                                               (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                } else {//取了平均值
                                    priority = (3100 + 7100) /2.0/
                                               (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                }
                            } else if (worktable_array[worktableIndexSellArray[j]].worktable_type == 5) {
                                if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState == 0) {//说明缺两种
                                    priority = (3000 + 3400 + 7800) / 3.0 /
                                               (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                } else {//取了平均值
                                    priority = (3200 + 7800) /2.0/
                                               (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                }
                            } else if (worktable_array[worktableIndexSellArray[j]].worktable_type == 6) {
                                if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState == 0) {//说明缺两种
                                    priority = (3200 + 3400 + 7800) / 3.0 /
                                               (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                } else {//取了平均值
                                    priority = (3300 + 7800) /2.0/
                                               (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                                }
                            }
                        }
                    } else {//如果在生产,那将没有优先级加成
                        priority = productPriorityArray[itemId].profit /
                                   (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));//买卖物品产生的优先级
                    }
                }
            } else if (worktable_array[worktableIndexSellArray[j]].worktable_type == 7) {//如果卖给7号
                if (worktable_array[worktableIndexBuyArray[i]].worktable_type == 4 &&
                    worktable_array7.size() == 1&&frameID<7321) {//箭头形
                    priority = 99999999 /
                               (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                } else {
                    //如果七号工作台没有生产,那就可以获得加成
                    if (worktable_array[worktableIndexSellArray[j]].remainingProductionTime <=
                        remainingProductionTime) {//没有在生产,或者快生产完,就给他
                        if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState == 0) {//缺三种
                            priority = (71400 / (6 + 3 + 1) * 3.0 -
                                        (3000 + 3200 + 3400 - productPriorityArray[itemId].profit)) /
                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                        } else if (worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                                   48 ||
                                   worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                                   80 ||
                                   worktable_array[worktableIndexSellArray[j]].rawMaterialCellState ==
                                   96) {//缺一种,取了中间值
                            priority = hyperParameterPriorityMap1 * hyperParameterPriorityMap1 *
                                       ((71400 - 14900 - 13300) / 4.0 * 3.0 - 3400 - 3000) /
                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                        } else {//缺两种,取了中间值
                            priority = hyperParameterPriorityMap1 * ((71400 - 14900) / 7.0 * 3.0 - 3000 - 3200) /
                                       (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));
                        }
                    } else {//没有七号的加成
                        priority = productPriorityArray[itemId].profit /
                                   (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));//买卖物品产生的优先级
                    }
                }

            } else {//如果卖给8或9,没有加成
                priority = productPriorityArray[itemId].profit /
                           (sqrt(distanceBetweenPoint) + sqrt(distanceBetween));//买卖物品产生的优先级
            }

//            //test
//            fprintf(stderr,
//                    "frameID %d robot[%d] buy[%.2f][%.2f]. sell[%.2f][%.2f] d1 %.2f d2 %.2f priority %.2f profit %.2f\n",
//                    frameID, robotId,
//                    worktable_array[worktableIndexBuyArray[i]].coordinate_x,
//                    worktable_array[worktableIndexBuyArray[i]].coordinate_y,
//                    worktable_array[worktableIndexSellArray[j]].coordinate_x,
//                    worktable_array[worktableIndexSellArray[j]].coordinate_y,
//                    sqrt(distanceBetweenPoint),
//                    sqrt(distanceBetween), priority,
//                    priority * (sqrt(distanceBetweenPoint) + sqrt(distanceBetween)));//买卖物品产生的优先级);

            if (maxPriority < priority) {//如果是最短路径,记录距离和走过的两个结点

                maxPriority = priority;
                minWorktableSellIndex = worktableIndexSellArray[j];
                minWorktableIndex = worktableIndexBuyArray[i];
            }
        }
    }//保存遍历的结果
    productPriorityArray[itemId].priority = maxPriority;
    productPriorityArray[itemId].minWorktableIndex = minWorktableIndex;
    productPriorityArray[itemId].minWorktableSellIndex = minWorktableSellIndex;
}

/**
 * 判断剩余时间是否足够买卖物品,判断思路为最少花费帧数*超参数系数hyperParameterTimeBuy>剩余帧数,说明时间不够(其实小于也不能说明时间够)
 * @param robot1 机器人
 * @param worktableBuy 买物品的工作台
 * @param worktableSell 卖物品的工作台
 * @param frameId 当前帧数
 * @return 时间够返回true,时间不够返回false
 */
bool isEnoughTimeBuy(robot &robot1, worktable &worktableBuy, worktable &worktableSell, int frameId) {//判读时间是否够买东西
    if (9000 - frameId < hyperParameterTimeBuy * 50.0 * (sqrt(distanceSquaredBetweenPoint(robot1, worktableBuy)) +
                                                         sqrt(distanceSquaredBetweenWorktable(worktableBuy,
                                                                                              worktableSell))) /
                         6.0) {//如果时间肯定不够,就不买
        return false;
    } else
        return true;
}

bool isRangeWorktable1(worktable &worktable1) {
    if (worktable1.coordinate_x < 21.0 && worktable1.coordinate_y < 15.0) {//4,左下一个
        return true;
    } else if (worktable1.coordinate_x > 28.0 && worktable1.coordinate_y < 15.0) {//6右下一个
        return true;
    } else if (worktable1.coordinate_x < 25.0 && worktable1.coordinate_x > 24.0 &&
               worktable1.coordinate_y > 23.0) {//5,上一个
        return true;
    } else if (worktable1.coordinate_y > 17.0 && worktable1.coordinate_y < 20.0 && worktable1.coordinate_x > 24.0 &&
               worktable1.coordinate_x < 27.0) {
        return true;
    } else {
        return false;
    }
}


bool isRangeWorktable2(worktable &worktable1, int robotId) {
    if (robotId == 0) {
        if (worktable1.coordinate_x > 40) {
            return false;
        } else if (worktable1.coordinate_y < 13) {
            return false;
        } else if (worktable1.coordinate_x < 2) {
            return false;
        } else if (worktable1.coordinate_x > 24 && worktable1.coordinate_x < 25 && worktable1.coordinate_y > 37 &&
                   worktable1.coordinate_y < 38) {
            return false;
        } else {
            return true;
        }
    } else if (robotId == 1) {
        if (worktable1.coordinate_x > 40) {
            return false;
        } else if (worktable1.coordinate_y < 13) {
            return false;
        } else if (worktable1.coordinate_x < 2 && worktable1.coordinate_y < 40) {
            return false;
        } else if (worktable1.coordinate_x > 2 && worktable1.coordinate_y > 49) {
            return false;
        } else if (worktable1.coordinate_x > 24 && worktable1.coordinate_x < 25 && worktable1.coordinate_y > 25 &&
                   worktable1.coordinate_y < 26) {
            return false;
        } else {
            return true;
        }
    } else if (robotId == 2) {
        if (worktable1.coordinate_x > 40) {
            return false;
        } else if (worktable1.coordinate_y > 37) {
            return false;
        } else if (worktable1.coordinate_x < 2) {
            return false;
        } else if (worktable1.coordinate_x > 24 && worktable1.coordinate_x < 25 && worktable1.coordinate_y > 12 &&
                   worktable1.coordinate_y < 13) {
            return false;
        } else {
            return true;
        }
    } else if (robotId == 3) {
        if (worktable1.coordinate_x > 40) {
            return false;
        } else if (worktable1.coordinate_y > 37) {
            return false;
        } else if (worktable1.coordinate_x < 2 && worktable1.coordinate_y > 4) {
            return false;
        } else if (worktable1.coordinate_x > 2 && worktable1.coordinate_y < 2) {
            return false;
        } else if (worktable1.coordinate_x > 24 && worktable1.coordinate_x < 25 && worktable1.coordinate_y > 25 &&
                   worktable1.coordinate_y < 26) {
            return false;
        } else {
            return true;
        }
    }
}

bool isRangeSellWorktable2(worktable &worktable1, int robotId) {
    if (robotId == 0) {
        if (worktable1.coordinate_x > 40) {
            return false;
        } else if (worktable1.coordinate_y < 13) {
            return false;
        } else if (worktable1.coordinate_x < 2) {
            return false;
        } else {
            return true;
        }
    } else if (robotId == 1) {
        if (worktable1.coordinate_x > 40) {
            return false;
        } else if (worktable1.coordinate_y < 13) {
            return false;
        } else if (worktable1.coordinate_x < 2 && worktable1.coordinate_y < 40) {
            return false;
        } else if (worktable1.coordinate_x > 2 && worktable1.coordinate_y > 49) {
            return false;
        } else if (worktable1.coordinate_x > 24 && worktable1.coordinate_x < 25 && worktable1.coordinate_y > 25 &&
                   worktable1.coordinate_y < 26) {
            return false;
        } else {
            return true;
        }
    } else if (robotId == 2) {
        if (worktable1.coordinate_x > 40) {
            return false;
        } else if (worktable1.coordinate_y > 37) {
            return false;
        } else if (worktable1.coordinate_x < 2) {
            return false;
        } else {
            return true;
        }
    } else if (robotId == 3) {
        if (worktable1.coordinate_x > 40) {
            return false;
        } else if (worktable1.coordinate_y > 37) {
            return false;
        } else if (worktable1.coordinate_x < 2 && worktable1.coordinate_y > 4) {
            return false;
        } else if (worktable1.coordinate_x > 2 && worktable1.coordinate_y < 2) {
            return false;
        } else if (worktable1.coordinate_x > 24 && worktable1.coordinate_x < 25 && worktable1.coordinate_y > 25 &&
                   worktable1.coordinate_y < 26) {
            return false;
        } else {
            return true;
        }
    }
}

bool isRangeWorktable3(worktable &worktable1) {
//    return true;
//    if(worktable1.coordinate_x == 27.25 && worktable1.coordinate_y == 49.25 ){
//        return false;
//    }else if(worktable1.coordinate_x == 44.25 && worktable1.coordinate_y == 32.75 ){
//        return false;
//    }
//    else
    if (worktable1.coordinate_x < 45.0 && worktable1.coordinate_x > 21.0 && worktable1.coordinate_y > 10.0 &&
        worktable1.coordinate_y < 50.0) {//
        return true;
    } else {
        return false;
    }
}

// 箭形图 划分区域
bool isRangeWorktable4(worktable &worktable1, int robotId) {
    // if (worktable1.coordinate_x < 45.0 && worktable1.coordinate_x > 20.0 && worktable1.coordinate_y > 10.0 &&
    //     worktable1.coordinate_y < 50.0) {//
    //     return true;
    // } else {
    //     return false;
    // }
    if (robotId == 3 || robotId == 2) {
        if (worktable1.coordinate_x < 24) {
            return false;
        }
        return true;
    } else {
        if (worktable1.coordinate_x < 24) {
            return false;
        }
        if (worktable1.coordinate_y < 2) {
            return false;
        }
        return true;
    }
}

/**
 * 改进方向:机器人调度算法,让同样的时间同样的行走速度,该算法可以获得更大的收益
 * 主函数主要实现机器人调度算法,主要部分为是1初始化数据,2读取输入,3解析输入,4是否可以买物品7,5是否可以促进物品7的生产,6四个机器人选择优先级最高的物品买或者选择最近的原材料格卖
 * 1.对下面提到的重要数据进行初始化
 * 2.通过input_every_frame()读取每一帧的输入
 * 3.对输入内容进行解析,将每个工作台的产品格与原材料格的状态存入allProductSelect
 * 4.判断是否可以买物品7,若可以安排离该工作台最近的机器人去买
 * 5.如果生产物品7的工作台只差一个原材料a,那就让没拿物品的机器人去买原材料a,如果地图有原材料a,机器人去买原材料a.若没有原材料a,则机器人按照优先级选择该买的物品
 * 6.按照robotId从0到3的顺序,机器人选择优先级最高的物品买或者选择最近的原材料格卖物品
 * 主函数中的重要数据
 *      vector<worktable> worktable_array; 存储所有工作台信息
 *      vector<robot> robot_array(4);      存所有的机器人信息
 *      vector<productPriority> productPriorityArray(7);  存储7种产品在当前帧,针对机器人robotId的优先级.若产品i对于机器人robotId的优先级最高,机器人出发去买产品i
 *      vector<int> allProductSelectSize0(7, 0), allProductSelectSize1(7, 0);  搭配allProductSelect使用,记录allProductSelect[i][0]与allProductSelect[i][1]的size(当时想着用空间换时间,但好像没什么用,系统不差这点时间)
 *      allProductSelect 三维数组,需搭配allProductSelectSize0和allProductSelectSize1使用,allProductSelect第一维存放7种物品,数组范围[0,6],
 *      (重要)            第二维存储两种状态买与卖,买0,卖1,第三维是allProductSelect[i][j]的下标,范围[0,allProductSelectSizej[i]-1].
 *                       举例allProductSelect[i][0].代表在当前帧机器人可以买第i+1种物品的所有工作台id的集合,
 *                       allProductSelect[i][0][k]=23代表工作台id=23可以买第i+1种物品,
 *                       allProductSelect[i][1]代表在当前帧机器人可以收购第i+1种物品的所有工作台id的集合,
 *                       allProductSelect[i][1][k]=21代表工作台id=21可以收购第i+1种物品,
 *     vector<int> availableWorktableBuyArray; 记录当前帧机器人robotId可以选择买物品的工作平台id
 *     vector<int> availableWorktableSellArray; 记录当前帧机器人robotId可以选择卖物品的工作平台id
 *     vector<worktable> worktable_array7; 记录生产物品7的工作台
 *
 * @return
 */
int main() {

    //初始化
    vector<worktable> worktable_array;//存所有的工作台信息
    vector<robot> robot_array(4);//存所有的机器人信息

    vector<productPriority> productPriorityArray(7);//产品的优先级
    productPriorityArray[0].profit = 3000.0;
    productPriorityArray[1].profit = 3200.0;
    productPriorityArray[2].profit = 3400.0;
    productPriorityArray[3].profit = 7100.0;
    productPriorityArray[4].profit = 7800.0;
    productPriorityArray[5].profit = 8300.0;
    productPriorityArray[6].profit = 29000.0;
    vector<int> worktableIndexArray(50, -1);
    vector<vector<int> > productSelectBuySell(
            2);//存放产品买卖的可选择工作台,productSelectBuySell[0]存放买的工作台,productSelectBuySell[1]存放卖的工作台
    productSelectBuySell[0] = worktableIndexArray;
    productSelectBuySell[1] = worktableIndexArray;
    vector<vector<vector<int> > > allProductSelect(7, productSelectBuySell);//存放7种产品买卖的可选择工作台,产品与下标对应为0-1,1-2,2-3..6-7
    vector<int> allProductSelectSize0(7, 0), allProductSelectSize1(7, 0);//记录allProductSelect的下标

    vector<int> availableWorktableBuyArray;//记录可以用的工作平台
    vector<int> availableWorktableSellArray;

    vector<int> minWorktableSellIndexArray(4);//最小出售工作台数组

    vector<worktable> worktable_array7;//记录工作平台7

    readUntilOK();
    puts("OK");
    fflush(stdout);
    int frameID;
    int money, k, i;

    while (scanf("%d", &frameID) != EOF) {
        input_every_frame(frameID, money, k, worktable_array, robot_array, worktable_array7);
        printf("%d\n", frameID);

        //填写allProductSelect数组,写之前把原来的内容清空
        for (i = 0; i < 7; i++) {//清空
            allProductSelect[i][0].assign(50, -1);
            allProductSelect[i][1].assign(50, -1);
            allProductSelectSize0[i] = allProductSelectSize1[i] = 0;
        }
        //清空后进行填写
        for (i = 0; i < worktable_array.size(); i++) {
            if (worktable_array[i].productCellStatus ==
                1) {//如果有工作台有产品,把产品编号-1即worktable_array[i].worktable_type-1就是下标,该下标存买工作台i
                allProductSelect[worktable_array[i].worktable_type - 1][0][allProductSelectSize0[
                        worktable_array[i].worktable_type - 1]] = i;
                allProductSelectSize0[worktable_array[i].worktable_type - 1]++;
            }
            //如果该工作台可用卖产品,进行记录
            for (int index = 1; index < 8; index++) {
                if (worktable_array[i].raw_material_cell[index] == '0') {//如果可以卖物品,记录工作台i;
                    allProductSelect[index - 1][1][allProductSelectSize1[index - 1]] = i;
                    allProductSelectSize1[index - 1]++;
                }
            }
        }

//先拿7号
        double minDistance7 = 999999.9, distance7;//机器人到7的距离
        int minRobotId7 = -1, minWorktableId7;
        if (frameID > 8500) {
            for (i = 0; i < worktable_array7.size(); i++) {//遍历每个七号工作台
//            //test
//            fprintf(stderr, "frameID %d worktable_array[%d] 5product %d\n", frameID,
//                    worktable_array7[i].worktableArrayIndex,
//                    worktable_array[worktable_array7[i].worktableArrayIndex].raw_material_cell_robot[5]);
//            if (worktable_array[worktable_array7[i].worktableArrayIndex].productCellStatus == 1) {
//                if (worktable_array[worktable_array7[i].worktableArrayIndex].raw_material_cell_robot[4] != -1 ||
//                    worktable_array[worktable_array7[i].worktableArrayIndex].raw_material_cell_robot[5] != -1 ||
//                    worktable_array[worktable_array7[i].worktableArrayIndex].raw_material_cell_robot[6] != -1) {
//                    break;
//                }
//            }

                if (worktable_array[worktable_array7[i].worktableArrayIndex].productCellStatus == 1) {//如果七号工作台有产品
                    for (int robotId = 0; robotId < 4; robotId++) {
                        if (robot_array[robotId].product_type == 0) {//没买到东西的机器人
                            distance7 = distanceSquaredBetweenPoint(robot_array[robotId],
                                                                    worktable_array7[i]);//计算去该工作台的距离
                            if (minDistance7 > distance7) {//如果距离最小,进行记录
//                           //test
//                            fprintf(stderr, "frameID %d robot_array[%d] distance7%f\n", frameID, robotId, distance7);
                                minDistance7 = distance7;
                                minRobotId7 = robotId;
                                minWorktableId7 = worktable_array7[i].worktableArrayIndex;//记录下标
                            }
                        }
//                    if (robot_array[robotId].worktableSelectionFlag != -1 &&
//                        robot_array[robotId].worktableSelectionFlag != worktable_array7[i].worktableArrayIndex) {//如果去往其他工作台的机器人马上就能得到物品了,就不能把对方叫过去
//                        if (robot_array[robotId].product_type == 0 && distanceSquaredBetweenPoint(robot_array[robotId],
//                                                                                                  worktable_array[robot_array[robotId].worktableSelectionFlag]) >
//                                                                      hyperParameterDistance) {//没买到东西的机器人,并且机器人离自己的目标比较远
//                            distance7 = distanceSquaredBetweenPoint(robot_array[robotId],
//                                                                    worktable_array7[i]);//计算去该工作台的距离
//                            if (minDistance7 > distance7) {//如果距离最小,进行记录
////                           //test
////                            fprintf(stderr, "frameID %d robot_array[%d] distance7%f\n", frameID, robotId, distance7);
//                                minDistance7 = distance7;
//                                minRobotId7 = robotId;
//                                minWorktableId7 = worktable_array7[i].worktableArrayIndex;//记录下标
//                            }
//                        }
//                    }else{
//
//                    }
                    }
                } else if (worktable_array[worktable_array7[i].worktableArrayIndex].remainingProductionTime >=
                           0) {//如果七号工作台没有产品,但在生产
                    for (int robotId = 0; robotId < 4; robotId++) {
                        if (robot_array[robotId].product_type == 0) {//没买到东西的机器人
                            distance7 = distanceSquaredBetweenPoint(robot_array[robotId],
                                                                    worktable_array7[i]);//计算去该工作台的距离
//                        //test
//                        fprintf(stderr, "frameID %d robot_array[%d] remainingProductionTime %d\n", frameID,
//                                robotId,
//                                worktable_array[worktable_array7[i].worktableArrayIndex].remainingProductionTime);
                            if (50 * sqrt(distance7) / 6 >=
                                worktable_array[worktable_array7[i].worktableArrayIndex].remainingProductionTime) {//如果去工作台的时间最小值大于工作台完成生产的时间,那说明机器人到了以后工作台已经生产完成,就进行记录
                                if (minDistance7 > distance7) {//如果距离最小,进行记录
//                                //test
//                                fprintf(stderr, "frameID %d robot_array[%d] distance7> remainingProductionTime %d\n",
//                                        frameID,
//                                        robotId,
//                                        worktable_array[worktable_array7[i].worktableArrayIndex].remainingProductionTime);
                                    minDistance7 = distance7;
                                    minRobotId7 = robotId;
                                    minWorktableId7 = worktable_array7[i].worktableArrayIndex;//记录下标
                                }
                            }
                        }
                    }
                }
            }
        }

        if (minRobotId7 != -1) {
            if (isEnoughTimeBuy(robot_array[minRobotId7], worktable_array[minWorktableId7],
                                worktable_array[allProductSelect[6][1][findShortestSellDistance(allProductSelect[6][1],
                                                                                                worktable_array,
                                                                                                worktable_array[minWorktableId7])]],
                                frameID)) {//如果时间足够
                //test
//                fprintf(stderr, "frameID %d robot_array[%d]  if (minRobotId7 != -1) {\n", frameID, minRobotId7);
                robot_to_destination(robot_array[minRobotId7],
                                     worktable_array[minWorktableId7],
                                     robot_array, worktable_array, frameID, worktable_array7);
            } else {
                minRobotId7 = -1;//如果没有买东西,将标记位置为-1
            }
        }

        for (int robotId = 0; robotId < 4; robotId++) {

            if (robot_array[robotId].product_type == 0) {//狂飙去买东西,

                if (robotId == minRobotId7) {//如果机器人有被提前安排的话,跳过;
                    continue;
                }
                int productPriorityIndex = 0;
                double maxPriority = 0;
                for (i = 0; i < 7; i++) {//求最大产品优先级,需要得到该买哪个产品,该去哪里买
                    //将上一轮的优先级清空
                    productPriorityArray[i].priority = 0;
                    //统计该产品的可用工作平台
                    availableWorktableBuyArray.clear();//先清空再用
                    availableWorktableSellArray.clear();//i*j选择最优的
                    for (int index = 0; index < allProductSelectSize0[i]; index++) {
                        if (worktable_array[allProductSelect[i][0][index]].productCellStatus == 1) {//如果有产品
                            if ((worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[1] != -1) ||
                                (worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[2] != -1) ||
                                (worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[3] != -1) ||
                                worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[4] != -1 ||
                                worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[5] != -1 ||
                                worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[6] !=
                                -1) {//如果有人送材料,就不用去这里买了,除非离得很近
                                if (distanceSquaredBetweenPoint(robot_array[robotId],
                                                                worktable_array[allProductSelect[i][0][index]]) >
                                    hyperParameterDistance) {
                                    continue;
                                }
                            }
                        }
                        int flagRobotIndex = 0;//标记
                        if (worktable_array7.size() != 0) {//针对r型图,不是r型图考虑距离
                            for (int robotIndex = 0; robotIndex < 4; robotIndex++) {
                                if (robotIndex != robotId) {//不是自己
                                    if (robot_array[robotIndex].product_type == 0) {//没买东西
                                        if (distanceSquaredBetweenPoint(robot_array[robotIndex],
                                                                        worktable_array[allProductSelect[i][0][index]]) <
                                            hyperParameterDistance) {//离得很近
                                            flagRobotIndex = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        if (flagRobotIndex == 1) {//如果有没背物品的机器人(不是自己)离工作台离得很近,那也不用考虑了
                            continue;
                        }

                        if (worktable_array7.size() > 2) {//专门处理心形图
                            if (isRangeWorktable1(worktable_array[allProductSelect[i][0][index]]) ||
                                frameID > 8697) {//工作台在范围内,才能有资格被选
                                if (worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                    -1 || worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                          robotId) {//如果worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] == -1时,
                                    // 意味着没有机器人用产品格,==robotId时,意味着自己用
                                    availableWorktableBuyArray.push_back(allProductSelect[i][0][index]);
                                }
//                                if(i<3){
//                                    availableWorktableBuyArray.push_back(allProductSelect[i][0][index]);
//                                }else{
//                                    if (worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
//                                        -1 || worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
//                                              robotId) {//如果worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] == -1时,
//                                        // 意味着没有机器人用产品格,==robotId时,意味着自己用
//                                        availableWorktableBuyArray.push_back(allProductSelect[i][0][index]);
//                                    }
//                                }
                            }
                        } else if (worktable_array7.size() == 0) {//针对r型图
                            if (isRangeWorktable3(worktable_array[allProductSelect[i][0][index]])) {//工作台在范围内,才能有资格被选
                                if (worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                    -1 || worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                          robotId) {//如果worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] == -1时,
                                    // 意味着没有机器人用产品格,==robotId时,意味着自己用
                                    availableWorktableBuyArray.push_back(allProductSelect[i][0][index]);
                                }
                            }
                        } else if (worktable_array7.size() == 2) { // 专门处理菱形图
                            if (isRangeWorktable2(worktable_array[allProductSelect[i][0][index]],
                                                  robotId)) { // 工作台在范围内,才能有资格被选
                                if (worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                    -1 ||
                                    worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                    robotId) { // 如果worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] == -1时,
                                    // 意味着没有机器人用产品格,==robotId时,意味着自己用
                                    availableWorktableBuyArray.push_back(allProductSelect[i][0][index]);
                                }
                            }
                        } else if (worktable_array7.size() == 1) { // 专门处理箭形图
                            if (isRangeWorktable4(worktable_array[allProductSelect[i][0][index]],
                                                  robotId)) { // 工作台在范围内,才能有资格被选
                                if (worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                    -1 ||
                                    worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                    robotId) { // 如果worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] == -1时,
                                    // 意味着没有机器人用产品格,==robotId时,意味着自己用
                                    availableWorktableBuyArray.push_back(allProductSelect[i][0][index]);
                                }
                            }
                        } else {
                            if (worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                -1 || worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] ==
                                      robotId) {//如果worktable_array[allProductSelect[i][0][index]].raw_material_cell_robot[0] == -1时,
                                // 意味着没有机器人用产品格,==robotId时,意味着自己用
                                availableWorktableBuyArray.push_back(allProductSelect[i][0][index]);
                            }
                        }

                    }
                    for (int index = 0; index < allProductSelectSize1[i]; index++) {
                        if (worktable_array7.size() > 2) {//专门处理心形图
                            if (isRangeWorktable1(worktable_array[allProductSelect[i][1][index]])||
                                frameID > 8697) {//工作台在范围内,才能有资格被选
                                if (worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                    -1 ||
                                    worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                    robotId) {//如果worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] == -1时,
                                    // 意味着没有机器人用这个工作台的i+1材料格,==robotId时,意味着自己用
                                    availableWorktableSellArray.push_back(allProductSelect[i][1][index]);
                                    for (int x = 0; x < minWorktableSellIndexArray.size(); x++) {
                                        if (x != robotId && minWorktableSellIndexArray[x] ==
                                                            allProductSelect[i][1][index]) {//如果有其他机器人想去该工作台卖东西,判断要用这个工作台的什么位置
                                            if (robot_array[x].worktableSelectionFlag != -1) {//如果这个机器人在当前帧有想要去的工作台
                                                if (robot_array[x].worktableSelectionFlag !=
                                                    minWorktableSellIndexArray[x]) {//如果机器人当前不是要去这个工作台卖东西,那就说明机器人要去其他工作台买东西,然后到这个工作台来卖
                                                    if (worktable_array[robot_array[x].worktableSelectionFlag].worktable_type ==
                                                        i + 1) {//机器人买物品的类型,就是当前物品,不能加入
                                                        availableWorktableSellArray.pop_back();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (worktable_array7.size() == 0) {//针对r型图
                            if (isRangeWorktable3(worktable_array[allProductSelect[i][1][index]])) {//工作台在范围内,才能有资格被选
                                if (worktable_array[allProductSelect[i][1][index]].worktable_type == 9) {
                                    worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[6] = -1;
                                }
                                if (worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                    -1 ||
                                    worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                    robotId) {//如果worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] == -1时,
                                    // 意味着没有机器人用这个工作台的i+1材料格,==robotId时,意味着自己用
                                    availableWorktableSellArray.push_back(allProductSelect[i][1][index]);
                                }
                            }
                        } else if (worktable_array7.size() == 2) { // 专门处理菱形图
                            if (isRangeSellWorktable2(worktable_array[allProductSelect[i][1][index]],
                                                      robotId)) { // 工作台在范围内,才能有资格被选
                                if (worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                    -1 ||
                                    worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                    robotId) { // 如果worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] == -1时,
                                    // 意味着没有机器人用这个工作台的i+1材料格,==robotId时,意味着自己用
                                    availableWorktableSellArray.push_back(allProductSelect[i][1][index]);
                                    for (int x = 0; x < minWorktableSellIndexArray.size(); x++) {
                                        if (x != robotId && minWorktableSellIndexArray[x] ==
                                                            allProductSelect[i][1][index]) { // 如果有其他机器人想去该工作台卖东西,判断要用这个工作台的什么位置
                                            if (robot_array[x].worktableSelectionFlag != -1) { // 如果这个机器人在当前帧有想要去的工作台
                                                if (robot_array[x].worktableSelectionFlag !=
                                                    minWorktableSellIndexArray[x]) { // 如果机器人当前不是要去这个工作台卖东西,那就说明机器人要去其他工作台买东西,然后到这个工作台来卖
                                                    if (worktable_array[robot_array[x].worktableSelectionFlag].worktable_type ==
                                                        i + 1) { // 机器人买物品的类型,就是当前物品,不能加入
                                                        availableWorktableSellArray.pop_back();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else  if (worktable_array7.size() == 1)
                        { // 专门处理菱形图
                            if (isRangeWorktable4(worktable_array[allProductSelect[i][1][index]],robotId))
                            { // 工作台在范围内,才能有资格被选
                                if (worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                    -1 ||
                                    worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                    robotId)
                                { // 如果worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] == -1时,
                                    // 意味着没有机器人用这个工作台的i+1材料格,==robotId时,意味着自己用
                                    availableWorktableSellArray.push_back(allProductSelect[i][1][index]);
                                    for (int x = 0; x < minWorktableSellIndexArray.size(); x++)
                                    {
                                        if (x != robotId && minWorktableSellIndexArray[x] ==
                                                            allProductSelect[i][1][index])
                                        { // 如果有其他机器人想去该工作台卖东西,判断要用这个工作台的什么位置
                                            if (robot_array[x].worktableSelectionFlag != -1)
                                            { // 如果这个机器人在当前帧有想要去的工作台
                                                if (robot_array[x].worktableSelectionFlag !=
                                                    minWorktableSellIndexArray[x])
                                                { // 如果机器人当前不是要去这个工作台卖东西,那就说明机器人要去其他工作台买东西,然后到这个工作台来卖
                                                    if (worktable_array[robot_array[x].worktableSelectionFlag].worktable_type ==
                                                        i + 1)
                                                    { // 机器人买物品的类型,就是当前物品,不能加入
                                                        availableWorktableSellArray.pop_back();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            if (worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                -1 || worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] ==
                                      robotId) {//如果worktable_array[allProductSelect[i][1][index]].raw_material_cell_robot[i + 1] == -1时,
                                // 意味着没有机器人用这个工作台的i+1材料格,==robotId时,意味着自己用
                                availableWorktableSellArray.push_back(allProductSelect[i][1][index]);
                                for (int x = 0; x < minWorktableSellIndexArray.size(); x++) {
                                    if (x != robotId && minWorktableSellIndexArray[x] ==
                                                        allProductSelect[i][1][index]) {//如果有其他机器人想去该工作台卖东西,判断要用这个工作台的什么位置
                                        if (robot_array[x].worktableSelectionFlag != -1) {//如果这个机器人在当前帧有想要去的工作台
                                            if (robot_array[x].worktableSelectionFlag !=
                                                minWorktableSellIndexArray[x]) {//如果机器人当前不是要去这个工作台卖东西,那就说明机器人要去其他工作台买东西,然后到这个工作台来卖
                                                if (worktable_array[robot_array[x].worktableSelectionFlag].worktable_type ==
                                                    i + 1) {//机器人买物品的类型,就是当前物品,不能加入
                                                    availableWorktableSellArray.pop_back();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
//                    //test
//                    fprintf(stderr, "frameID %d robotId %d Buy.size %d Sell.size %d allSellSize %d\n", frameID,
//                            robotId,
//                            availableWorktableBuyArray.size(),
//                            availableWorktableSellArray.size(), allProductSelectSize1[i]);
                    if (worktable_array7.size() != 0) {//针对r型图
                        if (1 == allProductSelectSize1[i]) {//如果只有一个卖的位置,那就只能有一个买家
                            for (int robotIndex = 0; robotIndex < robot_array.size(); robotIndex++) {
                                if (robotIndex != robotId) {
                                    if (robot_array[robotIndex].product_type ==
                                        i + 1) {//如果有机器人买了物品,那就说明没有卖的位置了,i从0到6,代表1到7号物品,
                                        availableWorktableSellArray.clear();
                                    }
                                    if (robot_array[robotIndex].product_type == 0 &&
                                        robot_array[robotIndex].worktableSelectionFlag != -1) {//或者有机器人要去买该物品,也说明没有卖的位置了
                                        if (worktable_array[robot_array[robotIndex].worktableSelectionFlag].worktable_type ==
                                            i + 1) {
                                            availableWorktableSellArray.clear();
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!availableWorktableBuyArray.empty() &&
                        !availableWorktableSellArray.empty()) {//如果产品可以买也可以卖,就考虑选择这个产品,计算对方的优先级
                        double minDistance = 999999.9;//暂时存放最短距离
                        int minWorktableIndex, minWorktableSellIndex;


                        //得到产品优先级
                        findMaxPriority(availableWorktableBuyArray, availableWorktableSellArray,
                                        worktable_array, robot_array, robotId,
                                        minDistance, minWorktableIndex, minWorktableSellIndex, productPriorityArray, i,
                                        worktable_array7, frameID);

                    }


                    if (productPriorityArray[i].priority > maxPriority) {//求最大优先级
                        maxPriority = productPriorityArray[i].priority;
                        productPriorityIndex = i;
                    }
                }
                if (productPriorityArray[productPriorityIndex].priority > 0) {//大于0,说明有的选,等于0,说明没有物品可以买
                    //test
//                    fprintf(stderr, "fID %d rId %d P[%d] %f\n", frameID,
//                            robotId, productPriorityIndex, productPriorityArray[productPriorityIndex].priority);

                    if (isEnoughTimeBuy(robot_array[robotId],
                                        worktable_array[productPriorityArray[productPriorityIndex].minWorktableIndex],
                                        worktable_array[productPriorityArray[productPriorityIndex].minWorktableSellIndex],
                                        frameID)) {//如果时间足够

                        minWorktableSellIndexArray[robotId] = productPriorityArray[productPriorityIndex].minWorktableSellIndex;
                        robot_to_destination(robot_array[robotId],
                                             worktable_array[productPriorityArray[productPriorityIndex].minWorktableIndex],
                                             robot_array, worktable_array, frameID, worktable_array7);
                    } else {//时间不够就走开
                        printf("forward %d %d\n", robotId, 1);
                        printf("rotate %d %f\n", robotId, 0.0);
                    }
                }
            } else {
                //先清空
                availableWorktableSellArray.clear();
                for (int index = 0;
                     index < allProductSelectSize1[robot_array[robotId].product_type - 1]; index++) {//查看可以去的工作台
                    if (worktable_array[allProductSelect[robot_array[robotId].product_type -
                                                         1][1][index]].worktable_type == 9)
                        for (int xz = 1; xz < 8; xz++)
                            worktable_array[allProductSelect[robot_array[robotId].product_type -
                                                             1][1][index]].raw_material_cell_robot[xz] =
                                    -1;
                    if (worktable_array[allProductSelect[robot_array[robotId].product_type -
                                                         1][1][index]].raw_material_cell_robot[robot_array[robotId].product_type] ==
                        -1 || worktable_array[allProductSelect[robot_array[robotId].product_type -
                                                               1][1][index]].raw_material_cell_robot[robot_array[robotId].product_type] ==
                              robotId) {
                        //如果worktable_array[allProductSelect[robot_array[robotId].product_type -1][1][index]].raw_material_cell_robot[robot_array[robotId].product_type] == -1时,
                        // 意味着工作台allProductSelect[robot_array[robotId].product_type -1][1][index]的原材料格robot_array[robotId].product_type没有被用
                        //==robotId时,意味着自己用
                        availableWorktableSellArray.push_back(
                                allProductSelect[robot_array[robotId].product_type - 1][1][index]);
                    }
                }
//                //test
//                fprintf(stderr, "else frameID %d\nrobotId %d\n availableWorktableSellArray.size %d\n\n", frameID,
//                        robotId,
//                        availableWorktableSellArray.size());

                if (!availableWorktableSellArray.empty()) {//如果有地方可去
                    double minDistance = 9999999.9;
                    int minWorktableIndex;

                    int index = 0;
                    for (index = 0; index < availableWorktableSellArray.size(); index++) {
                        if (availableWorktableSellArray[index] == minWorktableSellIndexArray[robotId]) {
//                            //test
//                            fprintf(stderr, "if frameID %d robotId %d  minWorktableSellIndexArray %d\n",
//                                    frameID,
//                                    robotId, minWorktableSellIndexArray[robotId]);
                            robot_to_destination(robot_array[robotId],
                                                 worktable_array[minWorktableSellIndexArray[robotId]], robot_array,
                                                 worktable_array,
                                                 frameID, worktable_array7);
                            break;
                        }
                    }
                    if (index == availableWorktableSellArray.size()) {
//                        //test
//                        fprintf(stderr, "else frameID %d robotId %d availableWorktableSellArray.size() \n",
//                                frameID, robotId);
                        //计算最大优先级
                        findMaxPrioritySellWorktable(availableWorktableSellArray, worktable_array, robot_array, robotId,
                                                     minDistance, minWorktableIndex, productPriorityArray,
                                                     worktable_array7);
                        minWorktableSellIndexArray[robotId] = minWorktableIndex;
                        robot_to_destination(robot_array[robotId], worktable_array[minWorktableIndex], robot_array,
                                             worktable_array,
                                             frameID, worktable_array7);
                    }
                }

            }
        }
        printf("OK\n");
        fflush(stdout);
    }

    return 0;
}
